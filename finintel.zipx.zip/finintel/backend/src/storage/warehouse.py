"""
Warehouse storage layer.
Handles parquet writes for the long/vertical financials table,
with versioning, partitioning, and master-table maintenance.
"""

from __future__ import annotations
import shutil
import uuid
from datetime import datetime
from pathlib import Path

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

from utils import get_logger, Paths
from storage.schema import (
    FINANCIALS_SCHEMA, COMPANY_MASTER_SCHEMA, SECTOR_MAPPING_SCHEMA, AUDIT_SCHEMA,
)

logger = get_logger("warehouse")


class Warehouse:
    """
    Manages the parquet warehouse.
    Tables:
      - company_master.parquet            (single file)
      - sector_mapping.parquet            (single file)
      - financials/                       (partitioned dataset by company_id/year)
      - audit_log.parquet                 (single file, append-only)
    """

    def __init__(self, paths: Paths):
        self.paths = paths
        self.paths.ensure()

    # ── Company master ──────────────────────────────────────────────

    def upsert_company_master(self, df: pd.DataFrame) -> None:
        """Replace company master from a DataFrame (company_id, company_name, ticker, isin, active_flag)."""
        # Coerce types to match schema
        df = df.copy()
        df["active_flag"] = df["active_flag"].astype(bool)
        tbl = pa.Table.from_pandas(df, schema=COMPANY_MASTER_SCHEMA, preserve_index=False)
        pq.write_table(tbl, self.paths.wh_company_master)
        logger.info(f"Wrote {len(df)} companies to {self.paths.wh_company_master.name}")

    def upsert_sector_mapping(self, df: pd.DataFrame) -> None:
        """Replace sector mapping (many-to-many) with provided DataFrame."""
        tbl = pa.Table.from_pandas(df, schema=SECTOR_MAPPING_SCHEMA, preserve_index=False)
        pq.write_table(tbl, self.paths.wh_sector_map)
        logger.info(f"Wrote {len(df)} sector mappings")

    def read_company_master(self) -> pd.DataFrame:
        if not self.paths.wh_company_master.exists():
            return pd.DataFrame(columns=[f.name for f in COMPANY_MASTER_SCHEMA])
        return pq.read_table(self.paths.wh_company_master).to_pandas()

    def read_sector_mapping(self) -> pd.DataFrame:
        if not self.paths.wh_sector_map.exists():
            return pd.DataFrame(columns=[f.name for f in SECTOR_MAPPING_SCHEMA])
        return pq.read_table(self.paths.wh_sector_map).to_pandas()

    # ── Financials (versioned fact table) ───────────────────────────

    def load_all_financials(self) -> pd.DataFrame:
        """Read the full financials dataset. Returns empty frame if none exist."""
        if not self.paths.wh_financials.exists() or not any(self.paths.wh_financials.rglob("*.parquet")):
            return pd.DataFrame(columns=[f.name for f in FINANCIALS_SCHEMA])
        ds = pq.ParquetDataset(str(self.paths.wh_financials))
        return ds.read().to_pandas()

    def ingest_financials(self, new_records: list[dict], ingestion_id: str | None = None) -> dict:
        """
        Ingest a batch of standardized records into the warehouse.

        Versioning algorithm:
          ROW KEY = (company_id, financial_category, financial_item, year)
          For each key:
            - Find max existing version V; new row gets V+1.
            - Mark all previously-active rows with that key as is_active=False.
            - The newest row is is_active=True.
          Within a single batch, if the same key appears more than once, keep
          the LAST occurrence (later = newer); earlier ones are dropped.

        Returns ingestion summary dict.
        """
        ingestion_id = ingestion_id or str(uuid.uuid4())

        # ── Dedup within batch: keep last occurrence per key ──
        deduped: dict = {}
        for r in new_records:
            k = (r["company_id"], r["financial_category"], r["financial_item"], r["year"])
            deduped[k] = r
        new_records = list(deduped.values())

        existing = self.load_all_financials()
        if not existing.empty:
            new_keys = {
                (r["company_id"], r["financial_category"], r["financial_item"], r["year"])
                for r in new_records
            }

            def in_new_keys(row):
                return (row["company_id"], row["financial_category"],
                        row["financial_item"], row["year"]) in new_keys

            mask = existing.apply(in_new_keys, axis=1)
            existing.loc[mask, "is_active"] = False
            grp = (existing
                   .groupby(["company_id", "financial_category", "financial_item", "year"])
                   ["version"].max())
            max_versions = grp.to_dict()
        else:
            max_versions = {}

        revised = 0
        for r in new_records:
            key = (r["company_id"], r["financial_category"], r["financial_item"], r["year"])
            prev = max_versions.get(key, 0)
            r["version"] = prev + 1
            if prev > 0:
                revised += 1
            r["is_active"] = True
            r["ingestion_id"] = ingestion_id
            if r.get("updated_on") is None:
                r["updated_on"] = datetime.utcnow()

        combined = pd.concat(
            [existing, pd.DataFrame(new_records)],
            ignore_index=True,
        ) if not existing.empty else pd.DataFrame(new_records)

        if self.paths.wh_financials.exists():
            shutil.rmtree(self.paths.wh_financials)
        self.paths.wh_financials.mkdir(parents=True, exist_ok=True)

        tbl = pa.Table.from_pandas(combined, schema=FINANCIALS_SCHEMA, preserve_index=False)
        pq.write_to_dataset(
            tbl,
            root_path=str(self.paths.wh_financials),
            partition_cols=["company_id", "year"],
        )

        self._append_audit(
            ingestion_id=ingestion_id,
            company_id=new_records[0]["company_id"] if new_records else "",
            source_file=new_records[0]["source_file"] if new_records else "",
            rows_loaded=len(new_records),
            rows_revised=revised,
            status="success",
            notes=f"new={len(new_records)-revised}, revised={revised}",
        )

        summary = {
            "ingestion_id": ingestion_id,
            "rows_loaded":  len(new_records),
            "rows_revised": revised,
            "rows_new":     len(new_records) - revised,
        }
        logger.info(f"Ingested batch: {summary}")
        return summary

    # ── Audit ───────────────────────────────────────────────────────

    def _append_audit(self, **kw) -> None:
        kw.setdefault("timestamp", datetime.utcnow())
        row_df = pd.DataFrame([kw])
        if self.paths.wh_audit.exists():
            old = pq.read_table(self.paths.wh_audit).to_pandas()
            combined = pd.concat([old, row_df], ignore_index=True)
        else:
            combined = row_df
        tbl = pa.Table.from_pandas(combined, schema=AUDIT_SCHEMA, preserve_index=False)
        pq.write_table(tbl, self.paths.wh_audit)

    def read_audit_log(self) -> pd.DataFrame:
        if not self.paths.wh_audit.exists():
            return pd.DataFrame(columns=[f.name for f in AUDIT_SCHEMA])
        return pq.read_table(self.paths.wh_audit).to_pandas()

    def deactivate_period(self, company_id: str, period: str) -> int:
        """
        Mark ALL rows for (company_id, year=period) as is_active=False.
        Used when analyst deletes all data for a period.
        Returns the number of rows deactivated.
        """
        existing = self.load_all_financials()
        if existing.empty:
            return 0

        mask = (existing["company_id"] == company_id) & (existing["year"] == period)
        n_deactivated = int(mask.sum())
        if n_deactivated == 0:
            return 0

        existing.loc[mask, "is_active"] = False

        if self.paths.wh_financials.exists():
            shutil.rmtree(self.paths.wh_financials)
        self.paths.wh_financials.mkdir(parents=True, exist_ok=True)

        tbl = pa.Table.from_pandas(
            existing, schema=FINANCIALS_SCHEMA, preserve_index=False
        )
        pq.write_to_dataset(
            tbl,
            root_path=str(self.paths.wh_financials),
            partition_cols=["company_id", "year"],
        )
        logger.info(f"Deactivated {n_deactivated} rows for {company_id}/{period}")
        return n_deactivated

    def deactivate_all(self, company_id: str) -> int:
        """
        Mark ALL rows for company_id as is_active=False.
        Used when analyst deletes all data for a company.
        """
        existing = self.load_all_financials()
        if existing.empty:
            return 0

        mask = existing["company_id"] == company_id
        n = int(mask.sum())
        if n == 0:
            return 0

        existing.loc[mask, "is_active"] = False

        if self.paths.wh_financials.exists():
            shutil.rmtree(self.paths.wh_financials)
        self.paths.wh_financials.mkdir(parents=True, exist_ok=True)

        tbl = pa.Table.from_pandas(
            existing, schema=FINANCIALS_SCHEMA, preserve_index=False
        )
        pq.write_to_dataset(
            tbl, root_path=str(self.paths.wh_financials),
            partition_cols=["company_id", "year"],
        )
        logger.info(f"Deactivated all {n} rows for {company_id}")
        return n
