"""
DuckDB query engine.
Provides a Python API + named query templates + arbitrary SQL execution
on top of the partitioned parquet warehouse.
"""

from __future__ import annotations
import json
from pathlib import Path

import duckdb
import pandas as pd

from utils import get_logger, Paths

logger = get_logger("query_engine")


class QueryEngine:
    """DuckDB façade over the parquet warehouse."""

    def __init__(self, paths: Paths):
        self.paths = paths
        self.con = duckdb.connect(database=":memory:")
        self._register_views()

    # ── View registration ──────────────────────────────────────────

    def _register_views(self):
        """Register parquet datasets as DuckDB views."""
        if any(self.paths.wh_financials.rglob("*.parquet")):
            glob = str(self.paths.wh_financials / "**" / "*.parquet")
            # parquet partition columns (company_id, year) are inferred by DuckDB
            self.con.execute(
                f"CREATE OR REPLACE VIEW financials AS "
                f"SELECT * FROM read_parquet('{glob}', hive_partitioning=true)"
            )
            self.con.execute(
                f"CREATE OR REPLACE VIEW financials_latest AS "
                f"SELECT * FROM financials WHERE is_active = TRUE"
            )
        if self.paths.wh_company_master.exists():
            self.con.execute(
                f"CREATE OR REPLACE VIEW company_master AS "
                f"SELECT * FROM read_parquet('{self.paths.wh_company_master}')"
            )
        if self.paths.wh_sector_map.exists():
            self.con.execute(
                f"CREATE OR REPLACE VIEW sector_mapping AS "
                f"SELECT * FROM read_parquet('{self.paths.wh_sector_map}')"
            )
        if self.paths.wh_audit.exists():
            self.con.execute(
                f"CREATE OR REPLACE VIEW audit_log AS "
                f"SELECT * FROM read_parquet('{self.paths.wh_audit}')"
            )
        logger.info("DuckDB views registered: financials, financials_latest, "
                    "company_master, sector_mapping, audit_log")

    def refresh(self):
        """Re-register views after warehouse updates."""
        self._register_views()

    # ── Generic SQL ────────────────────────────────────────────────

    def sql(self, query: str) -> pd.DataFrame:
        """Run an arbitrary SQL query and return a DataFrame."""
        logger.info(f"SQL: {query[:200].replace(chr(10), ' ')}…")
        return self.con.execute(query).df()

    # ── Built-in query methods ─────────────────────────────────────

    def get_company_history(self, company_id: str, category: str | None = None) -> pd.DataFrame:
        """All-latest financials for one company, optionally filtered by category."""
        where = f"company_id = '{company_id}' AND is_active = TRUE"
        if category:
            where += f" AND financial_category = '{category}'"
        return self.sql(
            f"SELECT financial_item, financial_category, year, value, units "
            f"FROM financials WHERE {where} ORDER BY year DESC, financial_item"
        )

    def get_item_trend(self, company_id: str, financial_item: str,
                       category: str | None = None) -> pd.DataFrame:
        """Trend of one line item across years for one company.
        If the same canonical name lives in multiple categories (e.g. Altman Z vs P&L),
        all are returned unless `category` is provided."""
        where = (f"company_id = '{company_id}' "
                 f"AND financial_item = '{financial_item}' AND is_active = TRUE")
        if category:
            where += f" AND financial_category = '{category}'"
        return self.sql(
            f"SELECT year, financial_category, value, units, version, updated_on "
            f"FROM financials WHERE {where} "
            f"ORDER BY year DESC, financial_category"
        )

    def get_sector_companies(self, sector: str) -> pd.DataFrame:
        """List companies tagged with a given sector."""
        return self.sql(
            f"SELECT DISTINCT cm.company_id, cm.company_name, cm.ticker, sm.sub_sector "
            f"FROM company_master cm JOIN sector_mapping sm USING(company_id) "
            f"WHERE sm.sector = '{sector}'"
        )

    def get_peer_compare(self, sector: str, financial_item: str, year: str) -> pd.DataFrame:
        """All companies in `sector`: latest value of `financial_item` for `year`."""
        return self.sql(
            f"SELECT cm.company_id, cm.company_name, f.value, f.units "
            f"FROM company_master cm "
            f"JOIN sector_mapping sm USING(company_id) "
            f"JOIN financials f USING(company_id) "
            f"WHERE sm.sector = '{sector}' "
            f"  AND f.financial_item = '{financial_item}' "
            f"  AND f.year = '{year}' "
            f"  AND f.is_active = TRUE "
            f"ORDER BY f.value DESC"
        )

    def get_latest_filings(self, limit: int = 20) -> pd.DataFrame:
        """Most recent ingestion runs from audit log."""
        return self.sql(
            f"SELECT ingestion_id, company_id, source_file, rows_loaded, "
            f"rows_revised, status, timestamp "
            f"FROM audit_log ORDER BY timestamp DESC LIMIT {limit}"
        )

    def get_revision_history(self, company_id: str, financial_item: str, year: str) -> pd.DataFrame:
        """Full version history (active + inactive) for one cell of data."""
        return self.sql(
            f"SELECT version, value, units, is_active, source_file, updated_on "
            f"FROM financials WHERE company_id = '{company_id}' "
            f"AND financial_item = '{financial_item}' AND year = '{year}' "
            f"ORDER BY version"
        )

    # ── Saved query templates ──────────────────────────────────────

    def run_template(self, template_name: str, params: dict) -> pd.DataFrame:
        """
        Execute a saved .sql template from query_templates/.
        Template uses Python str.format() style placeholders: {company_id}, {year}, etc.
        """
        tpl = self.paths.query_dir / f"{template_name}.sql"
        if not tpl.exists():
            raise FileNotFoundError(f"Query template not found: {tpl}")
        with open(tpl) as f:
            sql = f.read()
        # Sanitise params (basic — caller is internal/analyst)
        safe = {k: str(v).replace("'", "''") for k, v in params.items()}
        return self.sql(sql.format(**safe))

    def list_templates(self) -> list:
        if not self.paths.query_dir.exists():
            return []
        return sorted([p.stem for p in self.paths.query_dir.glob("*.sql")])

    # ── Cleanup ────────────────────────────────────────────────────

    def close(self):
        self.con.close()
