from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from app.services.analytics_service import AnalyticsService

router = APIRouter()
_svc = None

def get_svc():
    global _svc
    if _svc is None:
        _svc = AnalyticsService()
    return _svc

class SQLQuery(BaseModel):
    sql: str

@router.post("/sql")
async def run_sql(query: SQLQuery, svc: AnalyticsService = Depends(get_svc)):
    try:
        df = svc.engine.sql(query.sql)
        return df.to_dict("records")
    except Exception as e:
        raise HTTPException(400, str(e))

@router.get("/companies/{company_id}/history")
async def company_history(company_id: str, svc: AnalyticsService = Depends(get_svc)):
    try:
        df = svc.engine.get_company_history(company_id)
        return df.to_dict("records")
    except Exception as e:
        raise HTTPException(500, str(e))
