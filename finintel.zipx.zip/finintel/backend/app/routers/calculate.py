"""
calculate.py — ROUTE ORDER IS CRITICAL.
Static-prefix routes (/warehouse, /invalidate) MUST precede /{company_id}/{period}.
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from typing import Optional
from app.db.sqlite_db import get_db
from app.services.service_factory import get_fresh_service

router = APIRouter()


@router.post("/warehouse/{company_id}")
async def calculate_from_warehouse(company_id: str):
    """Run analysis directly from existing warehouse data."""
    svc = get_fresh_service()
    try:
        result = svc.run_analysis(company_id)
        return {"status": "ok", "result": result}
    except Exception as e:
        raise HTTPException(500, str(e))


@router.post("/invalidate/{company_id}")
async def invalidate_cache(
    company_id: str,
    period: Optional[str] = Query(None),
    db=Depends(get_db),
):
    """
    Hard invalidation: deactivates warehouse rows so dashboard shows empty.
    If period given: deactivate only that period.
    If no period: deactivate ALL periods for the company.

    This is called after analyst deletes values and saves — ensures the
    warehouse (Parquet) reflects the deletion, not just SQLite staging.
    """
    svc = get_fresh_service()

    if period:
        n = svc.remove_period_from_warehouse(company_id, period)
        detail = f"Deactivated {n} warehouse rows for {company_id}/{period}"
    else:
        n = svc.remove_all_from_warehouse(company_id)
        detail = f"Deactivated {n} warehouse rows for {company_id} (all periods)"

    await db.execute(
        "INSERT INTO audit_log(event_type,company_id,detail) VALUES('INVALIDATE',?,?)",
        (company_id, detail)
    )
    await db.execute(
        "UPDATE versions SET is_active=0 WHERE company_id=?",
        (company_id,)
    )
    await db.commit()

    return {
        "status":     "invalidated",
        "company_id": company_id,
        "period":     period,
        "rows_deactivated": n,
        "detail":     detail,
    }


@router.post("/{company_id}/{period}")
async def calculate(company_id: str, period: str, db=Depends(get_db)):
    """Ingest staged data and run Cost Structure + Altman Z analysis."""
    svc = get_fresh_service()
    async with db.execute(
        "SELECT financial_item, category, value, units, parent_item "
        "FROM financial_inputs WHERE company_id=? AND period_label=?",
        (company_id, period)
    ) as cur:
        staged = [dict(r) for r in await cur.fetchall()]

    if staged:
        try:
            ingest_result = svc.ingest_from_staging(company_id, period, staged)
        except Exception as e:
            raise HTTPException(500, f"Ingest failed: {e}")
        source = "staged"
    else:
        ingest_result = {"rows_loaded": 0, "note": "using warehouse data"}
        source = "warehouse"

    try:
        result = svc.run_analysis(company_id)
        await db.execute(
            "INSERT INTO audit_log(event_type,company_id,period_label,rows_affected) "
            "VALUES('CALCULATE',?,?,?)",
            (company_id, period, ingest_result.get("rows_loaded", 0))
        )
        await db.commit()
        return {"status": "ok", "source": source, "ingest": ingest_result, "result": result}
    except Exception as e:
        raise HTTPException(500, f"Analysis failed: {e}")
