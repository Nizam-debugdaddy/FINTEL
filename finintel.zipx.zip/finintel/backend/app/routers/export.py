import traceback, aiosqlite
from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import FileResponse, Response
from typing import Optional
from app.services.service_factory import get_fresh_service
from app.db.sqlite_db import DB

router = APIRouter()

async def _log_export(company_id: str, fmt: str, status: str, path: str = "", err: str = ""):
    try:
        async with aiosqlite.connect(DB) as db:
            await db.execute(
                "INSERT INTO export_log(company_id,format,status,file_path,error_msg) VALUES(?,?,?,?,?)",
                (company_id, fmt, status, path, err[:500])
            )
            await db.commit()
    except Exception:
        pass

@router.post("/excel/{company_id}")
async def export_excel(
    company_id: str,
    period: Optional[str] = Query(None),
    report_type: str = Query("consolidated"),
):
    svc = get_fresh_service()
    try:
        out_path = svc.generate_excel(company_id)
        await _log_export(company_id, "excel", "success", str(out_path))
        return FileResponse(
            str(out_path),
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            filename=f"Output_Analysis_{company_id}.xlsx"
        )
    except Exception as e:
        detail = f"{type(e).__name__}: {e}\n{traceback.format_exc()[-800:]}"
        await _log_export(company_id, "excel", "failed", err=detail)
        raise HTTPException(500, f"Excel export failed: {type(e).__name__}: {e}")

@router.post("/ppt/{company_id}")
async def export_ppt(
    company_id: str,
    period: Optional[str] = Query(None),
    report_type: str = Query("consolidated"),
):
    svc = get_fresh_service()
    try:
        from app.services.ppt_service import PPTService
        ppt_bytes = PPTService(svc).generate(company_id)
        await _log_export(company_id, "ppt", "success")
        return Response(
            ppt_bytes,
            media_type="application/vnd.openxmlformats-officedocument.presentationml.presentation",
            headers={"Content-Disposition": f"attachment; filename=Summary_{company_id}.pptx"}
        )
    except Exception as e:
        detail = f"{type(e).__name__}: {e}"
        await _log_export(company_id, "ppt", "failed", err=detail)
        raise HTTPException(500, f"PPT export failed: {detail}")

@router.post("/pdf/{company_id}")
async def export_pdf(
    company_id: str,
    period: Optional[str] = Query(None),
    report_type: str = Query("consolidated"),
):
    """
    Generate PDF for a company.
    Returns binary application/pdf — the frontend validates the %PDF magic bytes
    before saving; a 500 JSON error is distinguishable from valid PDF bytes.
    """
    svc = get_fresh_service()
    try:
        from app.services.pdf_service import PDFService
        pdf_bytes = PDFService(svc).generate(
            company_id,
            period=period,
            report_type=report_type,
        )
        await _log_export(company_id, "pdf", "success")
        return Response(
            pdf_bytes,
            media_type="application/pdf",
            headers={
                "Content-Disposition": f"attachment; filename=Report_{company_id}.pdf",
                "Content-Length": str(len(pdf_bytes)),
            }
        )
    except Exception as e:
        detail = f"{type(e).__name__}: {e}\n{traceback.format_exc()[-600:]}"
        await _log_export(company_id, "pdf", "failed", err=detail)
        # Return 500 so frontend can distinguish from valid PDF
        raise HTTPException(500, f"PDF export failed: {type(e).__name__}: {e}")

@router.get("/logs/{company_id}")
async def export_logs(company_id: str):
    async with aiosqlite.connect(DB) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM export_log WHERE company_id=? ORDER BY created_at DESC LIMIT 20",
            (company_id,)
        ) as cur:
            rows = await cur.fetchall()
    return [dict(r) for r in rows]
