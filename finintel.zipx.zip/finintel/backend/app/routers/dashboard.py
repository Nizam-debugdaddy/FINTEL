from fastapi import APIRouter, HTTPException, Query
from app.services.service_factory import get_fresh_service
import math

router = APIRouter()

def _clean(v):
    if v is None: return None
    try:
        f = float(v)
        return None if (math.isnan(f) or math.isinf(f)) else round(f, 4)
    except Exception:
        return v

def _clean_records(records):
    return [{k: _clean(v) if isinstance(v, float) else v for k, v in r.items()} for r in records]


@router.get("/{company_id}")
async def get_dashboard(
    company_id: str,
    period: str = Query(None),
    report_type: str = Query("consolidated"),
):
    try:
        svc = get_fresh_service()
        data = svc.get_dashboard_data(company_id, period=period, report_type=report_type)
        if not data:
            return {"company_id": company_id, "kpis": {}, "trend": {},
                    "cost_structure": [], "years": [],
                    "message": "No data — enter data in grid and click Analyze"}
        return data
    except Exception as e:
        raise HTTPException(500, str(e))


@router.get("/{company_id}/altman")
async def get_altman_detail(company_id: str, period: str = Query(None)):
    try:
        svc = get_fresh_service()
        return svc.get_altman_detail(company_id, period=period)
    except Exception as e:
        raise HTTPException(500, str(e))


@router.get("/{company_id}/health-score")
async def health_score(company_id: str, period: str = Query(None)):
    try:
        svc = get_fresh_service()
        data = svc.get_dashboard_data(company_id, period=period)
        kpis = data.get("kpis", {})
        score = 0
        components = []
        yoy    = (kpis.get("revenue") or {}).get("yoy")
        g = min(max((yoy or 0) / 20 * 25, 0), 25)
        score += g
        components.append({"name": "Growth",             "score": round(g, 1), "max": 25, "value": yoy})
        margin = (kpis.get("ebitda") or {}).get("margin")
        p = min(max((margin or 0) / 40 * 35, 0), 35)
        score += p
        components.append({"name": "Profitability",      "score": round(p, 1), "max": 35, "value": margin})
        z = (kpis.get("altman_z") or {}).get("value")
        b = min(max((z or 0) / 5 * 40, 0), 40) if z else 0
        score += b
        components.append({"name": "Bankruptcy Safety",  "score": round(b, 1), "max": 40, "value": z})
        grade = "A" if score >= 80 else "B" if score >= 65 else "C" if score >= 50 else "D"
        return {"company_id": company_id, "total_score": round(score, 1), "grade": grade, "components": components}
    except Exception as e:
        raise HTTPException(500, str(e))


# ── Peer endpoints — MUST come before /{company_id} routes ──────────

@router.get("/peer/multi")
async def multi_company_peer(
    companies: str = Query(...),
    metrics: str   = Query(...),
    period: str    = Query("FY25"),
    report_type: str = Query("consolidated"),
):
    """Compare multiple companies across metrics for a period.
    Computes derived metrics (EBIT, margins, ratios) server-side.
    """
    try:
        svc = get_fresh_service()
        co_list  = [c.strip() for c in companies.split(",") if c.strip()]
        met_list = [m.strip() for m in metrics.split(",") if m.strip()]

        result = {}
        for cid in co_list:
            dash = svc.get_dashboard_data(cid, period=period, report_type=report_type)
            if not dash:
                continue
            kpis = dash.get("kpis", {})
            row: dict = {"company_id": cid}
            # Map requested metrics to KPI values
            METRIC_MAP = {
                "Revenue from Operations": ("revenue",    "value"),
                "Revenue Growth":          ("revenue",    "growth_pct"),
                "EBITDA":                  ("ebitda",     "value"),
                "EBITDA Margin":           ("ebitda",     "margin"),
                "EBIT":                    ("ebit",       "value"),
                "EBIT Margin":             ("ebit",       "margin"),
                "PAT":                     ("pat",        "value"),
                "PAT Margin":              ("pat",        "margin"),
                "Total Assets":            ("total_assets","value"),
                "Net Worth":               ("net_worth",  "value"),
                "Current Ratio":           ("current_ratio","value"),
                "Working Capital":         ("working_capital","value"),
                "ROE":                     ("roe",        "value"),
                "Altman Z Score":          ("altman_z",   "value"),
            }
            for m in met_list:
                if m in METRIC_MAP:
                    kpi_key, sub_key = METRIC_MAP[m]
                    row[m] = _clean((kpis.get(kpi_key) or {}).get(sub_key))
                else:
                    # Try direct warehouse lookup
                    df = svc.engine.get_company_history(cid)
                    sub = df[(df["financial_item"] == m) & (df["year"] == period)]
                    row[m] = _clean(float(sub["value"].iloc[0])) if not sub.empty else None
            result[cid] = row

        return list(result.values())
    except Exception as e:
        raise HTTPException(500, str(e))


@router.get("/peer/{sector}/{item}/{period}")
async def peer_comparison(sector: str, item: str, period: str):
    try:
        svc = get_fresh_service()
        sector_clause = "" if sector.upper() == "ALL" else f"AND s.sector = '{sector}'"
        df = svc.engine.sql(f"""
            SELECT DISTINCT c.company_id, c.company_name, f.value, f.units
            FROM financials_latest f
            JOIN sector_mapping s ON f.company_id = s.company_id
            JOIN company_master c ON f.company_id = c.company_id
            WHERE f.financial_item = '{item}'
              AND f.year = '{period}'
              {sector_clause}
            ORDER BY f.value DESC
        """)
        return _clean_records(df.to_dict("records"))
    except Exception as e:
        raise HTTPException(500, str(e))


@router.get("/sector/{sector}/ranking")
async def sector_ranking(sector: str, period: str = "FY25"):
    """sector='ALL' returns all companies across sectors."""
    try:
        svc  = get_fresh_service()
        sector_clause = "" if sector.upper() == "ALL" else f"AND s.sector = '{sector}'"
        df = svc.engine.sql(f"""
            SELECT c.company_id, c.company_name,
                MAX(CASE WHEN f.financial_item='Revenue from Operations' THEN f.value END) as revenue,
                MAX(CASE WHEN f.financial_item='EBITDA'                  THEN f.value END) as ebitda,
                MAX(CASE WHEN f.financial_item='PAT'                     THEN f.value END) as pat,
                MAX(CASE WHEN f.financial_item='Total Assets'            THEN f.value END) as total_assets
            FROM financials_latest f
            JOIN sector_mapping s ON f.company_id = s.company_id
            JOIN company_master c ON f.company_id = c.company_id
            WHERE f.year = '{period}' {sector_clause}
            GROUP BY c.company_id, c.company_name
            ORDER BY revenue DESC NULLS LAST
        """)
        # Compute Altman Z per company from dashboard service
        records = _clean_records(df.to_dict("records"))
        for r in records:
            try:
                dash = svc.get_dashboard_data(r["company_id"], period=period)
                r["altman_z"] = _clean((dash.get("kpis") or {}).get("altman_z", {}).get("value"))
                ebitda = r.get("ebitda"); revenue = r.get("revenue")
                r["ebitda_margin"] = round(ebitda/revenue*100, 2) if (ebitda and revenue) else None
            except Exception:
                r["altman_z"] = None
        return records
    except Exception as e:
        raise HTTPException(500, str(e))
