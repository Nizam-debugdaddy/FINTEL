"""
peer.py — Dedicated peer comparison endpoints.

POST /peer/cost-structure   → cost stack data for N companies
POST /peer/multi-metric     → KPI grid for N companies × M metrics
POST /export/peer/png       → PNG image of both charts
POST /export/peer/ppt       → PowerPoint with 4 slides
"""
from __future__ import annotations
import math, io
from typing import List, Optional
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from app.services.service_factory import get_fresh_service

router = APIRouter()

# ── Cost-stack segment definitions (matches Excel engine output) ──────────────
COST_SEGMENTS = [
    ("Raw Material Cost",           ["Cost of materials consumed",
                                     "Purchases of stock-in-trade",
                                     "Changes in inventories"]),
    ("Consumables",                 ["Consumables"]),
    ("Power & Fuel",                ["Power, Fuel Electricity"]),
    ("Transportation",              ["Cost transportation"]),
    ("Manpower",                    ["Employee benefit expenses"]),
    ("Rest in Other Expenses",      ["Rest in Other Expenses"]),
    ("Finance Costs",               ["Finance costs"]),
    ("Depreciation & Amortization", ["Depreciation & amortisation"]),
    ("Remaining Expenses",          ["Remaining Expenses"]),
    ("Operational PBT",             ["Operational PBT"]),
]

COST_COLORS = [
    "#1A56DB", "#0D9488", "#7C3AED", "#D97706",
    "#DC2626", "#059669", "#0891B2", "#EA580C",
    "#8B5CF6", "#64748B",
]

METRIC_MAP = {
    # KPI sub-key lookups: (kpi_dict_key, sub_key)
    # kpi_dict_key must match analytics_service.get_dashboard_data() kpis dict
    "Revenue":                 ("revenue",        "value"),
    "Revenue from Operations": ("revenue",        "value"),
    "Revenue Growth":          ("revenue",        "growth_pct"),   # FIX: was missing
    "Revenue Growth %":        ("revenue",        "growth_pct"),   # FIX: was missing
    "EBITDA":                  ("ebitda",         "value"),
    "EBITDA Margin":           ("ebitda",         "margin"),
    "EBITDA Margin %":         ("ebitda",         "margin"),
    "EBIT":                    ("ebit",           "value"),
    "EBIT Margin %":           ("ebit",           "margin"),
    "PAT":                     ("pat",            "value"),
    "PAT Margin":              ("pat",            "margin"),
    "PAT Margin %":            ("pat",            "margin"),
    "Total Assets":            ("total_assets",   "value"),
    "Net Worth":               ("net_worth",      "value"),
    "Total Equity":            ("net_worth",      "value"),
    "Current Ratio":           ("current_ratio",  "value"),
    "Working Capital":         ("working_capital","value"),
    "ROE":                     ("roe",            "value"),
    "ROE %":                   ("roe",            "value"),
    "Altman Z Score":          ("altman_z",       "value"),
    # Finance Costs is NOT a KPI — fetched directly from warehouse (see fallback below)
    "Finance Costs":           ("__warehouse__",  "Finance Costs"),
    "Finance Cost":            ("__warehouse__",  "Finance Costs"),
    "Total Liabilities":       ("__warehouse__",  "Total Liabilities"),
}

# Warehouse fallback: items that exist in warehouse but not as dashboard KPIs
_WAREHOUSE_ITEMS = {
    "Finance Costs":     "Finance Costs",
    "Finance Cost":      "Finance Costs",
    "Total Liabilities": "Total Liabilities",
}


def _clean(v):
    if v is None: return None
    try:
        f = float(v)
        return None if (math.isnan(f) or math.isinf(f)) else round(f, 4)
    except Exception:
        return v


def _get_cost_structure(svc, company_id: str, period: str, report_type: str) -> dict:
    """
    Run the cost structure engine for one company and return segment values
    for the requested period (INR Mn).
    Tries multiple category names since different warehouse ingestions use
    different naming conventions (P&L Consolidated, P&L, P&L Standalone).
    """
    try:
        from cost_structure_analysis import CostStructureAnalysis
        # Try category names in priority order
        cats_to_try = (
            ["P&L Consolidated", "P&L"]
            if report_type == "consolidated"
            else ["P&L Standalone", "P&L"]
        )
        pnl, years = None, []
        for cat in cats_to_try:
            _pnl, _years = svc.reshaper.get_pnl_wide(company_id, cat)
            if not _pnl.empty and period in _years:
                pnl, years = _pnl, _years
                break
        if pnl is None or pnl.empty or period not in years:
            return {}
        cs = CostStructureAnalysis(pnl, years).run()

        # Build lookup: engine row label → value for requested period
        direct = cs["direct"]
        lookup: dict = {}
        for _, row in direct.iterrows():
            lbl = str(row.get("Particulars", ""))
            v = row.get(period)
            if v is not None:
                lookup[lbl] = float(v)

        result: dict = {}
        for seg_name, src_keys in COST_SEGMENTS:
            total = sum(lookup.get(k, 0) for k in src_keys)
            result[seg_name] = round(total, 2) if total else None

        result["_revenue"]    = lookup.get("Revenue from Ops")
        # Use engine's Total Cost if available; otherwise sum cost segments
        # (DRL and other companies may not store a Total Cost row)
        tc = lookup.get("Total Cost")
        if not tc:
            tc = sum(
                (result.get(seg) or 0)
                for seg, _ in COST_SEGMENTS
                if seg not in ("Operational PBT",)
            ) or None
        result["_total_cost"] = tc
        result["_company"]    = company_id
        result["_period"]     = period
        return result
    except Exception as e:
        return {"_error": str(e), "_company": company_id}


# ── Request models ────────────────────────────────────────────────────────────
class CostStructureRequest(BaseModel):
    companies:   List[str]
    period:      str = "FY25"
    report_type: str = "consolidated"
    unit:        str = "absolute"   # absolute | pct_revenue

class MultiMetricRequest(BaseModel):
    companies:   List[str]
    metrics:     List[str]
    period:      str = "FY25"
    report_type: str = "consolidated"

class PeerExportRequest(BaseModel):
    companies:     List[str]
    metrics:       List[str]
    period:        str = "FY25"
    report_type:   str = "consolidated"
    cost_unit:     str = "absolute"
    format:        str = "png"   # png | ppt


# ── Endpoints ─────────────────────────────────────────────────────────────────
@router.post("/cost-structure")
async def peer_cost_structure(req: CostStructureRequest):
    """
    Returns cost stack data for each company in req.companies.
    Response shape:
    {
      companies: [...],
      segments:  [...],
      colors:    [...],
      data: { company_id: { segment: value_mn, _revenue, _total_cost } }
    }
    """
    svc = get_fresh_service()
    result = {}
    for co in req.companies:
        cs = _get_cost_structure(svc, co, req.period, req.report_type)
        if cs and not cs.get("_error"):
            result[co] = {k: _clean(v) for k, v in cs.items()}

    seg_names = [s[0] for s in COST_SEGMENTS]
    return {
        "companies": req.companies,
        "segments":  seg_names,
        "colors":    COST_COLORS,
        "period":    req.period,
        "unit":      req.unit,
        "data":      result,
    }


@router.post("/multi-metric")
async def peer_multi_metric(req: MultiMetricRequest):
    """
    Returns KPI values for each company × metric combination.
    Response shape:
    {
      companies: [...],
      metrics: [...],
      data: [ { company_id, metric, value, label } ]
      table: { metric: { company_id: value } }
    }
    """
    svc = get_fresh_service()
    rows = []
    table: dict = {m: {} for m in req.metrics}

    for co in req.companies:
        dash = svc.get_dashboard_data(co, period=req.period, report_type=req.report_type)
        if not dash or dash.get("no_data"):
            continue
        kpis = dash.get("kpis", {})

        for metric in req.metrics:
            val = None
            if metric in METRIC_MAP:
                kpi_key, sub_key = METRIC_MAP[metric]
                if kpi_key == "__warehouse__":
                    # Fetch directly from warehouse — not a dashboard KPI
                    try:
                        wh_df = svc.engine.get_company_history(co)
                        wh_row = wh_df[
                            (wh_df["financial_item"] == sub_key) &
                            (wh_df["year"] == req.period)
                        ]
                        val = _clean(float(wh_row["value"].iloc[0])) if not wh_row.empty else None
                    except Exception:
                        val = None
                else:
                    val = _clean((kpis.get(kpi_key) or {}).get(sub_key))
            rows.append({"company_id": co, "metric": metric, "value": val})
            table[metric][co] = val

    return {
        "companies": req.companies,
        "metrics":   req.metrics,
        "period":    req.period,
        "data":      rows,
        "table":     table,
    }


@router.post("/export/png")
async def export_peer_png(req: PeerExportRequest):
    """
    Generate a cost structure PNG using matplotlib (no Chrome/kaleido required).
    """
    from fastapi.responses import Response
    from app.services.chart_builder import make_cost_structure_chart

    svc = get_fresh_service()
    cost_data: dict = {}
    for co in req.companies:
        cs = _get_cost_structure(svc, co, req.period, req.report_type)
        if cs and not cs.get("_error"):
            cost_data[co] = {k: _clean(v) for k, v in cs.items()}

    png = make_cost_structure_chart(
        cost_data, req.companies, req.period,
        unit=req.cost_unit, width_in=10, height_in=5.5, dpi=180
    )
    return Response(png, media_type="image/png",
                    headers={"Content-Disposition": f"attachment; filename=cost_structure_{req.period}.png"})


@router.post("/export/ppt")
async def export_peer_ppt(req: PeerExportRequest):
    """
    Generate a 5-slide peer comparison PPT matching the CIPLA template format.
    Uses matplotlib for chart images (no Chrome/kaleido required).
    """
    from fastapi.responses import Response
    from app.services.chart_builder import (
        make_cost_structure_chart, make_multi_metric_chart
    )
    from app.services.peer_ppt_builder import build_peer_ppt

    svc = get_fresh_service()

    # ── Gather cost structure data ─────────────────────────────────
    cost_data: dict = {}
    for co in req.companies:
        cs = _get_cost_structure(svc, co, req.period, req.report_type)
        if cs and not cs.get("_error"):
            cost_data[co] = {k: _clean(v) for k, v in cs.items()}

    # ── Gather metric table ────────────────────────────────────────
    metric_table: dict = {m: {} for m in req.metrics}
    for co in req.companies:
        dash = svc.get_dashboard_data(co, period=req.period, report_type=req.report_type)
        if not dash or dash.get("no_data"):
            continue
        kpis = dash.get("kpis", {})
        for metric in req.metrics:
            if metric in METRIC_MAP:
                kpi_key, sub_key = METRIC_MAP[metric]
                if kpi_key == "__warehouse__":
                    try:
                        wh_df = svc.engine.get_company_history(co)
                        row = wh_df[(wh_df["financial_item"] == sub_key) & (wh_df["year"] == req.period)]
                        metric_table[metric][co] = _clean(float(row["value"].iloc[0])) if not row.empty else None
                    except Exception:
                        metric_table[metric][co] = None
                else:
                    metric_table[metric][co] = _clean((kpis.get(kpi_key) or {}).get(sub_key))

    # ── Generate chart images ──────────────────────────────────────
    cost_png_abs = make_cost_structure_chart(
        cost_data, req.companies, req.period,
        unit="absolute", width_in=12, height_in=5.5, dpi=150
    )
    cost_png_pct = make_cost_structure_chart(
        cost_data, req.companies, req.period,
        unit="pct_revenue", width_in=12, height_in=5.5, dpi=150
    )
    metric_png = make_multi_metric_chart(
        metric_table, req.companies, req.metrics, req.period,
        width_in=8.5, height_in=5.5, dpi=150
    )

    # ── Build PPT ──────────────────────────────────────────────────
    ppt_bytes = build_peer_ppt(
        companies=req.companies,
        period=req.period,
        report_type=req.report_type,
        cost_data=cost_data,
        metric_table=metric_table,
        metrics=req.metrics,
        cost_png_abs=cost_png_abs,
        cost_png_pct=cost_png_pct,
        metric_png=metric_png,
    )
    filename = f"peer_comparison_{req.period}.pptx"
    return Response(
        ppt_bytes,
        media_type="application/vnd.openxmlformats-officedocument.presentationml.presentation",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )


@router.post("/trend")
async def peer_trend(req: TrendRequest):
    """
    Returns a single metric's value for each company across a year range.
    Used for the Metric Trend Comparison section in Peer Comparison.
    Response:
    {
      companies: [...],
      years: [...],          # sorted years within range
      metric: "...",
      series: [              # one entry per company
        { company_id, values: [v_y0, v_y1, ...] }
      ]
    }
    """
    svc = get_fresh_service()

    # Build sorted year list (FY19–FY30 range supported)
    FY_ORDER = [f"FY{y}" for y in range(19, 31)]
    try:
        s_idx = FY_ORDER.index(req.start_year)
        e_idx = FY_ORDER.index(req.end_year)
        years = FY_ORDER[min(s_idx, e_idx): max(s_idx, e_idx) + 1]
    except ValueError:
        # Fallback for quarterly labels or non-standard formats
        years = [req.start_year, req.end_year]

    kpi_key, sub_key = METRIC_MAP.get(req.metric, (None, None))
    is_warehouse = kpi_key == "__warehouse__"

    series = []
    for co in req.companies:
        values: list = []
        for yr in years:
            val = None
            try:
                if is_warehouse:
                    wh_df = svc.engine.get_company_history(co)
                    row = wh_df[
                        (wh_df["financial_item"] == sub_key) & (wh_df["year"] == yr)
                    ]
                    val = _clean(float(row["value"].iloc[0])) if not row.empty else None
                elif kpi_key:
                    dash = svc.get_dashboard_data(co, period=yr, report_type=req.report_type)
                    if dash and not dash.get("no_data"):
                        val = _clean((dash.get("kpis", {}).get(kpi_key) or {}).get(sub_key))
            except Exception:
                val = None
            values.append(val)
        series.append({"company_id": co, "values": values})

    return {
        "companies":   req.companies,
        "years":       years,
        "metric":      req.metric,
        "metric_label": next((m["label"] for m in [
            {"value": k, "label": k} for k in METRIC_MAP
        ] if m["value"] == req.metric), req.metric),
        "series":      series,
    }
