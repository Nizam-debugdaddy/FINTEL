"""
AnalyticsService — wraps existing legacy engines without modifying them.
"""
import sys, uuid, math
from pathlib import Path
from datetime import datetime
from typing import Optional

from app.config import settings

sys.path.insert(0, str(settings.SRC_PATH))
sys.path.insert(0, str(settings.LEGACY_PATH))

from utils import Paths, get_logger
from storage import Warehouse
from retrieval import QueryEngine
from analytics_integration.reshaper import WarehouseReshaper
from standardization import Normalizer

logger = get_logger("analytics_service")

CAT_PRIORITY = {"P&L Consolidated": 0, "Altman Z": 1, "P&L Standalone": 2}


class AnalyticsService:
    def __init__(self):
        self.paths = Paths(settings.WAREHOUSE_PATH.parent).ensure()
        self.paths.warehouse          = settings.WAREHOUSE_PATH
        self.paths.mappings           = settings.MAPPINGS_PATH
        self.paths.legacy             = settings.LEGACY_PATH
        self.paths.output             = settings.OUTPUT_PATH
        self.paths.wh_company_master  = settings.WAREHOUSE_PATH / "company_master.parquet"
        self.paths.wh_sector_map      = settings.WAREHOUSE_PATH / "sector_mapping.parquet"
        self.paths.wh_financials      = settings.WAREHOUSE_PATH / "financials"
        self.paths.wh_audit           = settings.WAREHOUSE_PATH / "audit_log.parquet"
        self.paths.mapping_lineitem   = settings.MAPPINGS_PATH / "line_item_mapping.json"

        self.warehouse  = Warehouse(self.paths)
        self.engine     = QueryEngine(self.paths)
        self.reshaper   = WarehouseReshaper(self.engine)
        self.normalizer = Normalizer(self.paths.mapping_lineitem)

    # ── Staging → Warehouse ──────────────────────────────────────────

    def ingest_from_staging(self, company_id: str, period: str, staged_rows: list) -> dict:
        ingestion_id = str(uuid.uuid4())
        records = []
        for row in staged_rows:
            if row.get("value") is None:
                continue
            try:
                v = float(row["value"])
            except (TypeError, ValueError):
                continue
            cat = row.get("category", "P&L Consolidated")
            if "Altman" in cat:
                cat = "Altman Z"
            elif "Standalone" in cat:
                cat = "P&L Standalone"
            else:
                cat = "P&L Consolidated"
            records.append({
                "company_id": company_id, "company_name": company_id,
                "financial_item": row["financial_item"],
                "financial_category": cat, "year": period,
                "value": v, "units": row.get("units", "INR Million"),
                "source_file": f"web_input:{company_id}/{period}",
                "version": None, "is_active": True,
                "updated_on": datetime.utcnow(), "ingestion_id": ingestion_id,
            })
        if not records:
            return {"rows_loaded": 0, "rows_revised": 0}
        result = self.warehouse.ingest_financials(records, ingestion_id)
        self.engine.refresh()
        return result

    def remove_period_from_warehouse(self, company_id: str, period: str) -> int:
        """
        Deactivate all warehouse rows for a specific (company, period).
        Called when analyst deletes and saves — ensures dashboard shows no data
        for that period instead of stale values.
        """
        n = self.warehouse.deactivate_period(company_id, period)
        self.engine.refresh()
        return n

    def remove_all_from_warehouse(self, company_id: str) -> int:
        """Deactivate ALL warehouse rows for a company."""
        n = self.warehouse.deactivate_all(company_id)
        self.engine.refresh()
        return n

    # ── Run engines ──────────────────────────────────────────────────

    def run_analysis(self, company_id: str) -> dict:
        from cost_structure_analysis import CostStructureAnalysis
        from bankruptcy_analysis import BankruptcyAnalysis

        self.engine.refresh()
        pnl_co,  years_co  = self.reshaper.get_pnl_wide(company_id, "P&L Consolidated")
        pnl_std, years_std = self.reshaper.get_pnl_wide(company_id, "P&L Standalone")
        altman,  years_alt = self.reshaper.get_altman_wide(company_id)

        years = years_co or years_alt or []
        if not years:
            raise ValueError(f"No data in warehouse for {company_id}")

        result = {"company_id": company_id, "years": years}
        if not pnl_co.empty:
            cs = CostStructureAnalysis(pnl_co, years).run()
            result["cost_structure"] = self._serialize_cs(cs, years)
        if not altman.empty:
            bk = BankruptcyAnalysis(altman, pnl_co if not pnl_co.empty else altman, years).run()
            result["bankruptcy"] = self._serialize_bk(bk, years)
        return result

    def generate_excel(self, company_id: str) -> Path:
        from cost_structure_analysis import CostStructureAnalysis
        from bankruptcy_analysis import BankruptcyAnalysis
        from excel_writer import ExcelWriter

        self.engine.refresh()
        pnl_co,  years_co  = self.reshaper.get_pnl_wide(company_id, "P&L Consolidated")
        pnl_std, years_std = self.reshaper.get_pnl_wide(company_id, "P&L Standalone")
        altman,  years_alt = self.reshaper.get_altman_wide(company_id)
        years = years_co or years_alt

        if not years:
            raise ValueError(f"No warehouse data for {company_id}. Run analysis first.")

        co_results  = CostStructureAnalysis(pnl_co, years).run()
        std_results = CostStructureAnalysis(pnl_std, years).run() if not pnl_std.empty else co_results
        bk_results  = BankruptcyAnalysis(altman, pnl_co, years).run()

        try:
            cm = self.engine.sql(f"SELECT company_name, ticker FROM company_master WHERE company_id='{company_id}'")
            co_label = f"{cm.iloc[0]['company_name']} ({cm.iloc[0]['ticker']})" if not cm.empty else company_id
        except Exception:
            co_label = company_id

        out_path = settings.OUTPUT_PATH / f"Output_Analysis_{company_id}.xlsx"
        out_path.parent.mkdir(parents=True, exist_ok=True)
        writer = ExcelWriter(str(out_path), years, company_name=co_label)
        writer.write(bk_results, co_results, std_results)
        return out_path

    # ── Dashboard data ───────────────────────────────────────────────

    def get_dashboard_data(
        self, company_id: str,
        period: Optional[str] = None,
        report_type: str = "consolidated"
    ) -> dict:
        try:
            df = self.engine.get_company_history(company_id)
        except Exception:
            return {}
        if df.empty:
            return {"company_id": company_id, "no_data": True, "kpis": {}, "trend": {},
                    "cost_structure": [], "years": [], "message": "No warehouse data for this company"}

        # Apply report type filter for PnL items
        cat_filter = "P&L Consolidated" if report_type == "consolidated" else "P&L Standalone"

        years_sorted = sorted(df["year"].unique(), reverse=True)
        # If period specified, verify it has data
        latest_year = period if period and period in years_sorted else years_sorted[0] if years_sorted else None
        if not latest_year:
            return {"company_id": company_id, "no_data": True, "kpis": {}, "trend": {},
                    "cost_structure": [], "years": list(years_sorted), "message": "No data for selected period"}
        # Warn if requested period has no rows (even though other years exist)
        period_has_data = any(df["year"] == latest_year)
        if period and period not in years_sorted:
            return {"company_id": company_id, "no_data": True, "kpis": {}, "trend": {},
                    "cost_structure": [], "years": list(years_sorted),
                    "message": f"No data for {period}. Available: {', '.join(years_sorted)}"}
        prev_idx = years_sorted.index(latest_year) + 1 if latest_year in years_sorted else None
        prev_year = years_sorted[prev_idx] if prev_idx and prev_idx < len(years_sorted) else None

        def get_val(item, year=None, prefer_cat=None):
            y = year or latest_year
            sub = df[(df["financial_item"] == item) & (df["year"] == y)].copy()
            if sub.empty:
                return None
            if prefer_cat:
                sub_cat = sub[sub["financial_category"] == prefer_cat]
                if not sub_cat.empty:
                    return float(sub_cat["value"].iloc[0])
            sub["_p"] = sub["financial_category"].map(lambda c: CAT_PRIORITY.get(c, 9))
            return float(sub.sort_values("_p")["value"].iloc[0])

        def yoy(item):
            c = get_val(item, latest_year)
            p = get_val(item, prev_year) if prev_year else None
            if c is not None and p and p != 0:
                return round((c - p) / abs(p) * 100, 2)
            return None

        def margin(num, denom):
            n, d = get_val(num), get_val(denom)
            if n is not None and d and d != 0:
                return round(n / d * 100, 2)
            return None

        rev        = get_val("Revenue from Operations", prefer_cat=cat_filter)
        ebitda_val = get_val("EBITDA")
        dep_val    = get_val("Depreciation and Amortisation")
        # EBIT = EBITDA − Depreciation (matches Excel engine logic)
        ebit_val   = round(ebitda_val - dep_val, 2) if (ebitda_val is not None and dep_val is not None) else get_val("EBIT")

        kpis = {
            "revenue":        {"value": rev, "yoy": yoy("Revenue from Operations"), "unit": "INR Mn"},
            "ebitda":         {"value": ebitda_val, "margin": round(ebitda_val/rev*100,2) if (ebitda_val and rev) else None, "unit": "INR Mn"},
            "ebit":           {"value": ebit_val,   "margin": round(ebit_val/rev*100,2)   if (ebit_val and rev)   else None, "unit": "INR Mn"},
            "pat":            {"value": get_val("PAT"), "margin": margin("PAT","Revenue from Operations"), "unit": "INR Mn"},
            "total_assets":   {"value": get_val("Total Assets"), "yoy": yoy("Total Assets"), "unit": "INR Mn"},
            "net_worth":      {"value": get_val("Net Worth"), "unit": "INR Mn"},
            "current_ratio":  {"value": self._safe_div(get_val("Current Assets"), get_val("Current Liabilities"))},
            "roe":            {"value": self._safe_div(get_val("PAT"), get_val("Net Worth"), pct=True)},
            "working_capital":{"value": self._safe_sub(get_val("Current Assets"), get_val("Current Liabilities")), "unit":"INR Mn"},
        }
        # Revenue Growth %
        rev_prior = get_val("Revenue from Operations", year=prev_year, prefer_cat=cat_filter) if prev_year else None
        if rev and rev_prior and rev_prior != 0:
            kpis["revenue"]["growth_pct"] = round((rev - rev_prior) / abs(rev_prior) * 100, 2)

        # Altman Z — compute directly from components if not stored in warehouse
        z_sub = df[(df["financial_item"] == "Altman Z Score") & (df["year"] == latest_year)]
        if not z_sub.empty:
            z = float(z_sub["value"].iloc[0])
            kpis["altman_z"] = {"value": z, "zone": "safe" if z > 2.99 else "grey" if z > 1.81 else "distress"}
        else:
            # Compute from raw components in warehouse
            def _get(item): return get_val(item, latest_year)
            ta   = _get("Total Assets") or 1
            wc   = (_get("Current Assets") or 0) - (_get("Current Liabilities") or 0)
            re_  = _get("Other Equity (Includes Reserves)") or _get("Retained Earnings") or 0
            ebit = _get("EBIT") or ((_get("EBITDA") or 0) - (_get("Depreciation and Amortisation") or 0))
            mv   = _get("Market Capitalization") or 0
            rev  = _get("Revenue from Operations") or 0
            tl   = ta - (_get("Net Worth") or _get("Total Equity") or 0)
            if ta > 0:
                x1 = wc / ta
                x2 = re_ / ta
                x3 = ebit / ta
                x4 = mv / max(tl, 1)
                x5 = rev / ta
                z  = round(1.2*x1 + 1.4*x2 + 3.3*x3 + 0.6*x4 + 1.0*x5, 2)
                kpis["altman_z"] = {"value": z, "zone": "safe" if z > 2.99 else "grey" if z > 1.81 else "distress"}

        # Trend — deduplicated per year
        trend: dict = {}
        for item in ["Revenue from Operations", "PAT", "Total Assets"]:
            idf = df[df["financial_item"] == item].copy()
            if idf.empty:
                continue
            idf["_p"] = idf["financial_category"].map(lambda c: CAT_PRIORITY.get(c, 9))
            deduped = idf.sort_values("_p").groupby("year", as_index=False).first().sort_values("year")
            trend[item] = [{"year": r["year"], "value": r["value"]} for _, r in deduped.iterrows()]

        # EBITDA trend: run the Excel Cost Structure engine per report type
        # This guarantees YoY matches the Excel export (source of truth).
        ebitda_series = []
        ebitda_engine_vals: dict = {}  # year -> value from engine
        try:
            from cost_structure_analysis import CostStructureAnalysis
            _pnl_cat = "P&L Consolidated" if report_type == "consolidated" else "P&L Standalone"
            _pnl_df, _pnl_yrs = self.reshaper.get_pnl_wide(company_id, _pnl_cat)
            if not _pnl_df.empty:
                _cs = CostStructureAnalysis(_pnl_df, _pnl_yrs).run()
                for _, _row in _cs["direct"].iterrows():
                    if "EBITDA" in str(_row.get("Particulars", "")).upper():
                        for _yr in _pnl_yrs:
                            _v = _row.get(_yr)
                            if _v is not None:
                                ebitda_engine_vals[_yr] = float(_v)
                        break
        except Exception:
            pass  # fall through to warehouse lookup below

        for yr in sorted(years_sorted):
            if yr in ebitda_engine_vals:
                ebitda_series.append({"year": yr, "value": ebitda_engine_vals[yr]})
            else:
                # Fallback: warehouse lookup
                def _gvy(it, _yr=yr):
                    s = df[(df["financial_item"] == it) & (df["year"] == _yr)]
                    return float(s["value"].iloc[0]) if not s.empty else None
                rv_ = _gvy("Revenue from Operations")
                co_ = _gvy("Total Cost")
                fi_ = _gvy("Finance Costs") or 0
                de_ = _gvy("Depreciation and Amortisation") or 0
                if rv_ is not None and co_ is not None:
                    ebd_ = round(rv_ - co_ + fi_ + de_, 2)
                else:
                    ebd_ = _gvy("EBITDA")
                if ebd_ is not None:
                    ebitda_series.append({"year": yr, "value": ebd_})

        if ebitda_series:
            trend["EBITDA"] = ebitda_series

        # EBIT trend: EBITDA - Depreciation per year
        ebit_series = []
        for pt in ebitda_series:
            yr = pt["year"]
            def _gvy2(it, _yr=yr):
                s = df[(df["financial_item"]==it) & (df["year"]==_yr)]
                return float(s["value"].iloc[0]) if not s.empty else None
            dep_ = _gvy2("Depreciation and Amortisation")
            if dep_ is not None:
                ebit_series.append({"year": yr, "value": round(pt["value"] - dep_, 2)})
        if ebit_series:
            trend["EBIT"] = ebit_series

        z_trend_df = df[df["financial_item"] == "Altman Z Score"].sort_values("year")
        if not z_trend_df.empty:
            trend["Altman Z Score"] = [{"year": r["year"], "value": r["value"]}
                                        for _, r in z_trend_df.iterrows()]
        else:
            # Compute Z per year from Altman input components
            z_series = []
            for yr in sorted(years_sorted):
                def gvy(item):
                    s = df[(df["financial_item"]==item) & (df["year"]==yr)]
                    return float(s["value"].iloc[0]) if not s.empty else None
                ta_ = gvy("Total Assets") or 1
                wc_ = (gvy("Current Assets") or 0) - (gvy("Current Liabilities") or 0)
                re_ = gvy("Other Equity (Includes Reserves)") or gvy("Retained Earnings") or 0
                eb_ = gvy("EBIT") or ((gvy("EBITDA") or 0) - (gvy("Depreciation and Amortisation") or 0))
                mv_ = gvy("Market Capitalization") or 0
                rv_ = gvy("Revenue from Operations") or 0
                tl_ = ta_ - (gvy("Net Worth") or gvy("Total Equity") or 0)
                if ta_ > 0:
                    z_ = round(1.2*(wc_/ta_) + 1.4*(re_/ta_) + 3.3*(eb_/ta_) + 0.6*(mv_/max(tl_,1)) + 1.0*(rv_/ta_), 2)
                    z_series.append({"year": yr, "value": z_})
            if z_series:
                trend["Altman Z Score"] = z_series

        # Cost structure — use same canonical aggregation as Excel engine (source of truth)
        def gv_cost(item): return get_val(item, latest_year, prefer_cat=cat_filter) or 0

        raw_mat = (gv_cost("Cost of Materials Consumed")
                 + gv_cost("Purchases of Stock-in-Trade")
                 + gv_cost("Changes in Inventories"))

        cost_canonical = [
            ("Raw Material Cost",           raw_mat if raw_mat else None),
            ("Consumables",                 gv_cost("Consumables") or None),
            ("Power & Fuel",                gv_cost("Power, Fuel and Electricity") or None),
            ("Transportation",              gv_cost("Transportation Cost") or None),
            ("Manpower",                    gv_cost("Employee Benefit Expenses") or None),
            ("Rest in Other Expenses",      gv_cost("Rest in Other Expenses") or None),
            ("Finance Costs",               gv_cost("Finance Costs") or None),
            ("Depreciation & Amortization", gv_cost("Depreciation and Amortisation") or None),
        ]
        cost_data = [
            {"item": label, "value": val}
            for label, val in cost_canonical
            if val and val > 0
        ]

        return self._clean_nan({
            "company_id": company_id, "latest_year": latest_year,
            "years": years_sorted, "kpis": kpis,
            "trend": trend, "cost_structure": cost_data,
            "report_type": report_type,
        })

    def get_altman_detail(self, company_id: str, period: Optional[str] = None) -> dict:
        """Return full Altman Z decomposition for a specific period.
        Always returns complete structure with null values for missing components —
        never returns {} silently, so the frontend can show N/A instead of hiding table.
        """
        _empty_components = {
            "X1": {"value": None, "weight": 1.2, "name": "Working Capital / Total Assets"},
            "X2": {"value": None, "weight": 1.4, "name": "Retained Earnings / Total Assets"},
            "X3": {"value": None, "weight": 3.3, "name": "EBIT / Total Assets"},
            "X4": {"value": None, "weight": 0.6, "name": "Market Value of Equity / Total Liabilities"},
            "X5": {"value": None, "weight": 1.0, "name": "Sales / Total Assets"},
        }
        try:
            df = self.engine.get_company_history(company_id)
        except Exception:
            return {"year": period, "z_score": None, "zone": "unknown",
                    "components": _empty_components, "z_trend": [], "error": "Warehouse unavailable"}
        if df.empty:
            return {"year": period, "z_score": None, "zone": "unknown",
                    "components": _empty_components, "z_trend": [],
                    "message": "No warehouse data for this company"}

        years_sorted = sorted(df["year"].unique(), reverse=True)
        year = period if period and period in years_sorted else years_sorted[0] if years_sorted else None
        if not year:
            return {}

        def gv(item):
            sub = df[(df["financial_item"] == item) & (df["year"] == year)]
            return float(sub["value"].iloc[0]) if not sub.empty else None

        ta  = gv("Total Assets") or 1
        rev = gv("Revenue from Operations") or gv("Total Revenue")
        wc  = (gv("Current Assets") or 0) - (gv("Current Liabilities") or 0)
        mv  = gv("Market Capitalization") or gv("Market Value")
        tl  = (gv("Total Assets") or 0) - (gv("Net Worth") or gv("Total Equity") or 0)

        # X2: Retained Earnings — stored as "Other Equity (Includes Reserves)" in warehouse
        re  = (gv("Other Equity (Includes Reserves)")
               or gv("Retained Earnings")
               or gv("Retained Earning"))

        # X3: EBIT — not stored; compute from EBITDA − Depreciation (Excel engine method)
        ebitda = gv("EBITDA")
        dep    = gv("Depreciation and Amortisation")
        ebit   = round(ebitda - dep, 2) if (ebitda is not None and dep is not None) else gv("EBIT")

        x1 = self._safe_div(wc,   ta)
        x2 = self._safe_div(re,   ta)
        x3 = self._safe_div(ebit, ta)
        x4 = self._safe_div(mv,   tl if tl else 1)
        x5 = self._safe_div(rev,  ta)

        # Compute Z from all 5 components; if some missing use partial
        z_parts = [x1, x2, x3, x4, x5]
        weights = [1.2, 1.4, 3.3, 0.6, 1.0]
        if all(v is not None for v in z_parts):
            z = round(sum(v*w for v,w in zip(z_parts, weights)), 2)
        else:
            # Partial Z from available components
            partial = sum(v*w for v,w in zip(z_parts, weights) if v is not None)
            z = round(partial, 2) if any(v is not None for v in z_parts) else None

        # Historical Z scores — compute per year (not from stored Altman Z Score item)
        z_trend = []
        for _yr in sorted(df["year"].unique()):
            def _gvz(it, __yr=_yr):
                s = df[(df["financial_item"]==it) & (df["year"]==__yr)]
                return float(s["value"].iloc[0]) if not s.empty else None
            _ta  = _gvz("Total Assets") or 1
            _wc  = (_gvz("Current Assets") or 0) - (_gvz("Current Liabilities") or 0)
            _re  = _gvz("Other Equity (Includes Reserves)") or _gvz("Retained Earnings") or 0
            _ebd = _gvz("EBITDA");  _dep = _gvz("Depreciation and Amortisation")
            _eb  = round(_ebd - _dep, 2) if (_ebd is not None and _dep is not None) else _gvz("EBIT")
            _mv  = _gvz("Market Capitalization") or 0
            _rv  = _gvz("Revenue from Operations") or 0
            _tl  = _ta - (_gvz("Net Worth") or 0)
            if _ta > 0 and _eb is not None:
                _z = round(1.2*(_wc/_ta) + 1.4*(_re/_ta) + 3.3*(_eb/_ta)
                           + 0.6*(_mv/max(_tl,1)) + 1.0*(_rv/_ta), 2)
                z_trend.append({"year": _yr, "value": _z})

        return self._clean_nan({
            "year": year, "z_score": z,
            "zone": "safe" if z and z > 2.99 else "grey" if z and z > 1.81 else "distress",
            "components": {
                "X1": {"value": x1, "weight": 1.2, "name": "Working Capital / Total Assets"},
                "X2": {"value": x2, "weight": 1.4, "name": "Retained Earnings / Total Assets"},
                "X3": {"value": x3, "weight": 3.3, "name": "EBIT / Total Assets"},
                "X4": {"value": x4, "weight": 0.6, "name": "Market Value of Equity / Total Liabilities"},
                "X5": {"value": x5, "weight": 1.0, "name": "Sales / Total Assets"},
            },
            "z_trend": z_trend,
        })

    # ── Helpers ──────────────────────────────────────────────────────

    @staticmethod
    def _safe_div(n, d, pct=False):
        if n is None or not d or d == 0:
            return None
        r = n / d
        return round(r * 100, 2) if pct else round(r, 4)

    @staticmethod
    def _safe_sub(a, b):
        if a is None or b is None:
            return None
        return a - b

    @staticmethod
    def _clean_nan(obj):
        if isinstance(obj, float):
            return None if (math.isnan(obj) or math.isinf(obj)) else obj
        if isinstance(obj, dict):
            return {k: AnalyticsService._clean_nan(v) for k, v in obj.items()}
        if isinstance(obj, list):
            return [AnalyticsService._clean_nan(v) for v in obj]
        return obj

    @staticmethod
    def _serialize_cs(cs: dict, years: list) -> dict:
        result = {}
        for key, df in cs.items():
            if hasattr(df, "to_dict"):
                try:
                    result[key] = AnalyticsService._clean_nan(df.to_dict("records"))
                except Exception:
                    result[key] = str(df)
        return result

    @staticmethod
    def _serialize_bk(bk: dict, years: list) -> dict:
        result = {}
        for key, val in bk.items():
            if hasattr(val, "to_dict"):
                try:
                    result[key] = AnalyticsService._clean_nan(val.to_dict("records"))
                except Exception:
                    result[key] = str(val)
            else:
                result[key] = AnalyticsService._clean_nan(val)
        return result
