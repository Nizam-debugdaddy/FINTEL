"""Service factory — creates AnalyticsService instances."""
from functools import lru_cache
from app.services.analytics_service import AnalyticsService

# One instance per process — DuckDB is in-memory and thread-safe for reads
@lru_cache(maxsize=1)
def get_analytics_service() -> AnalyticsService:
    return AnalyticsService()

def get_fresh_service() -> AnalyticsService:
    """Get service but refresh DuckDB views first."""
    svc = get_analytics_service()
    svc.engine.refresh()
    return svc
