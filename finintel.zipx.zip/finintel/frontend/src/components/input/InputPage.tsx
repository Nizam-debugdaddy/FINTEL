import React, {
  useState, useEffect, useCallback, useRef, useMemo
} from 'react'
import {
  Box, Stack, Button, Typography, Alert, CircularProgress, Chip,
  Snackbar, Paper, Tabs, Tab, ToggleButton, ToggleButtonGroup,
  Dialog, DialogTitle, DialogContent, DialogActions, TextField,
  MenuItem, Tooltip, Menu, ListItemIcon, ListItemText,
  Divider as MuiDivider, InputAdornment, IconButton as MuiIconButton,
  LinearProgress
} from '@mui/material'
import { AgGridReact } from 'ag-grid-react'
import { ColDef, CellValueChangedEvent, ICellRendererParams } from 'ag-grid-community'
import 'ag-grid-community/styles/ag-grid.css'
import 'ag-grid-community/styles/ag-theme-alpine.css'
import { bulkSave, InputRow, api, fetchWorkspace, invalidateCache } from '../../api/client'
import { useFilter } from '../../App'

import PlayArrowIcon      from '@mui/icons-material/PlayArrow'
import SaveIcon           from '@mui/icons-material/Save'
import AddIcon            from '@mui/icons-material/Add'
import UndoIcon           from '@mui/icons-material/Undo'
import RedoIcon           from '@mui/icons-material/Redo'
import ContentCopyIcon    from '@mui/icons-material/ContentCopy'
import DeleteOutlineIcon  from '@mui/icons-material/DeleteOutline'
import SearchIcon         from '@mui/icons-material/Search'
import ClearIcon          from '@mui/icons-material/Clear'
import LockIcon           from '@mui/icons-material/Lock'
import LockOpenIcon       from '@mui/icons-material/LockOpen'
import DiscardIcon        from '@mui/icons-material/Restore'
import WarningIcon        from '@mui/icons-material/Warning'
import SubdirectoryArrowRightIcon from '@mui/icons-material/SubdirectoryArrowRight'
import ExpandMoreIcon     from '@mui/icons-material/ExpandMore'
import ChevronRightIcon   from '@mui/icons-material/ChevronRight'

// ─── Types ────────────────────────────────────────────────────────────────────
type GRow    = Record<string, any>
type HistEntry = { rows: GRow[]; desc: string }
type FreezeMode = 'frozen' | 'editing'
type RowSource  = 'warehouse' | 'staged' | 'empty'

interface CellCoord { row: number; col: string }
interface SelRange  { start: CellCoord; end: CellCoord }

// ─── Constants ────────────────────────────────────────────────────────────────
const CRORE_TO_MN = 10
const CATS        = ['Altman Z', 'P&L Consolidated', 'P&L Standalone']
const UNIT_OPTS   = ['INR Million', 'INR Crore', '%', 'Ratio', 'Days']
const MAX_DEPTH   = 3
const INDENT_PX   = 20
const SEL_COLOR   = 'rgba(25,118,210,0.13)'
const SEL_BORDER  = '1.5px solid #1976D2'

// Cell background by source + freeze mode
const BG = {
  frozen_warehouse: '#F8FAFC',
  frozen_staged:    '#FFF7ED',
  frozen_empty:     '#F8FAFC',
  editing_modified: '#FFF3E0',  // orange tint — cell was modified
  editing_value:    '#EEF2FF',  // has a value
  editing_empty:    '#FFFBEB',
}

// ─── Range helpers ────────────────────────────────────────────────────────────
function rangeToSet(range: SelRange | null, years: string[]): Set<string> {
  if (!range) return new Set()
  const r0 = Math.min(range.start.row, range.end.row)
  const r1 = Math.max(range.start.row, range.end.row)
  const c0 = Math.min(years.indexOf(range.start.col), years.indexOf(range.end.col))
  const c1 = Math.max(years.indexOf(range.start.col), years.indexOf(range.end.col))
  const s = new Set<string>()
  for (let r = r0; r <= r1; r++)
    for (let c = c0; c <= c1; c++)
      s.add(`${r}::${years[c]}`)
  return s
}

function cellCount(range: SelRange | null, years: string[]): number {
  if (!range) return 0
  const r = Math.abs(range.end.row - range.start.row) + 1
  const c0 = years.indexOf(range.start.col); const c1 = years.indexOf(range.end.col)
  if (c0 < 0 || c1 < 0) return 0
  return r * (Math.abs(c1 - c0) + 1)
}

// ─── Tree helpers ─────────────────────────────────────────────────────────────
function buildTree(flat: GRow[]): GRow[] {
  const byKey      = new Map<string, GRow>()
  const childrenOf = new Map<string, GRow[]>()
  const roots: GRow[] = []
  flat.forEach(r => byKey.set(r.financial_item, r))
  flat.forEach(r => {
    const p = r.parent_item
    if (!p || !byKey.has(p)) roots.push(r)
    else { if (!childrenOf.has(p)) childrenOf.set(p, []); childrenOf.get(p)!.push(r) }
  })
  const out: GRow[] = []
  function walk(rows: GRow[], depth: number) {
    rows.forEach(r => {
      const ch = childrenOf.get(r.financial_item) || []
      out.push({ ...r, _depth: depth, _hasChildren: ch.length > 0 })
      if (!r._collapsed && ch.length) walk(ch, depth + 1)
    })
  }
  walk(roots, 0)
  return out
}

function sumChildren(rows: GRow[], parent: GRow, years: string[]): GRow {
  const ch = rows.filter(r => r.parent_item === parent.financial_item)
  if (!ch.length) return parent
  const u = { ...parent }
  years.forEach(y => {
    if (ch.some(c => c[y] != null)) u[y] = ch.reduce((s, c) => s + (c[y] ?? 0), 0)
  })
  return u
}

// ─── Particulars cell renderer ─────────────────────────────────────────────
function ParticularsRenderer(p: ICellRendererParams & {
  onToggle: (item: string) => void
  onRename: (item: string, name: string) => void
  editingRow: string | null
  setEditingRow: (v: string | null) => void
  frozen: boolean
}) {
  const { data, onToggle, onRename, editingRow, setEditingRow, frozen } = p
  if (!data) return null
  const depth = data._depth || 0
  const [draft, setDraft] = useState(data.financial_item)
  const isEditing = !frozen && editingRow === data.financial_item
  return (
    <Box sx={{ display:'flex', alignItems:'center', pl:`${depth*INDENT_PX}px`, height:'100%', gap:0.3 }}>
      {data._hasChildren
        ? <Box component="span" onClick={() => onToggle(data.financial_item)}
            sx={{ cursor:'pointer', color:'#F97316', display:'flex', alignItems:'center', flexShrink:0 }}>
            {data._collapsed ? <ChevronRightIcon sx={{fontSize:16}}/> : <ExpandMoreIcon sx={{fontSize:16}}/>}
          </Box>
        : depth > 0
          ? <SubdirectoryArrowRightIcon sx={{fontSize:13,color:'#94A3B8',flexShrink:0}}/>
          : <Box sx={{width:16,flexShrink:0}}/>
      }
      {isEditing
        ? <input autoFocus value={draft}
            onChange={e => setDraft(e.target.value)}
            onBlur={() => { onRename(data.financial_item, draft); setEditingRow(null) }}
            onKeyDown={e => {
              if (e.key==='Enter') { onRename(data.financial_item, draft); setEditingRow(null) }
              if (e.key==='Escape') setEditingRow(null)
            }}
            style={{ flex:1, border:'1px solid #F97316', borderRadius:4, padding:'2px 6px',
              fontSize:13, fontWeight:depth===0?600:400, outline:'none' }}
          />
        : <span
            onDoubleClick={() => { if (!frozen) { setDraft(data.financial_item); setEditingRow(data.financial_item) } }}
            style={{ flex:1, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap',
              fontSize:13, fontWeight:depth===0?600:400, color:depth===0?'#0B2545':'#475569',
              cursor: frozen ? 'default' : 'text' }}
            title={frozen ? data.financial_item : 'Double-click to rename'}>
            {data.financial_item}
          </span>
      }
    </Box>
  )
}

// ─── Main Component ────────────────────────────────────────────────────────────
export default function InputPage() {
  const { filter } = useFilter()
  const { company: companyId, periodType: mode, reportType } = filter

  const [rows, setRows]             = useState<GRow[]>([])
  const [years, setYears]           = useState<string[]>([])
  const [activeTab, setActiveTab]   = useState(0)
  const [unit, setUnit]             = useState<'million'|'crore'>('million')
  const [loading, setLoading]       = useState(false)
  const [analyzing, setAnalyzing]   = useState(false)
  const [saving, setSaving]         = useState(false)
  const [dirty, setDirty]           = useState(false)
  const [hadDeletes, setHadDeletes] = useState(false) // track if user deleted cells
  const [freezeMode, setFreezeMode] = useState<FreezeMode>('frozen')
  const [dataSource, setDataSource] = useState<'warehouse'|'staged'|'empty'>('empty')
  const [snack, setSnack]           = useState<{msg:string;sev:'success'|'error'|'info'|'warning'}|null>(null)
  const [addYearOpen, setAddYearOpen]   = useState(false)
  const [newYearVal, setNewYearVal]     = useState('')
  const [search, setSearch]             = useState('')
  const [editingRow, setEditingRow]     = useState<string|null>(null)
  const [ctxMenu, setCtxMenu]           = useState<{x:number;y:number;rowData:GRow}|null>(null)
  const [deleteColDlg, setDeleteColDlg] = useState<string|null>(null)
  const [discardDlg, setDiscardDlg]     = useState(false)
  const [modifiedCells, setModifiedCells] = useState<Set<string>>(new Set())

  // Selection
  const [selRange, setSelRange]   = useState<SelRange|null>(null)
  const selCellsRef = useRef<Set<string>>(new Set())
  const isDragging  = useRef(false)
  const dragStart   = useRef<CellCoord|null>(null)

  // History
  const history    = useRef<HistEntry[]>([])
  const histIdx    = useRef<number>(-1)
  const gridRef    = useRef<any>(null)
  const rowsRef    = useRef<GRow[]>([])
  const yearsRef   = useRef<string[]>([])
  const origRowsRef = useRef<GRow[]>([]) // frozen baseline for discard
  const saveTimer  = useRef<ReturnType<typeof setTimeout>>()

  useEffect(() => { yearsRef.current = years }, [years])

  // ── History helpers ──────────────────────────────────────────────
  const snapshot = (desc: string, data: GRow[]) => {
    history.current = history.current.slice(0, histIdx.current + 1)
    history.current.push({ rows: JSON.parse(JSON.stringify(data)), desc })
    if (history.current.length > 50) history.current.shift()
    histIdx.current = history.current.length - 1
  }

  const applyRows = useCallback((newRows: GRow[], autoSave = true) => {
    rowsRef.current = newRows
    setRows([...newRows])
    setDirty(true)
    if (autoSave) {
      clearTimeout(saveTimer.current)
      saveTimer.current = setTimeout(() => doSave(newRows, false), 1200)
    }
  }, [])

  const undo = useCallback(() => {
    if (histIdx.current <= 0) return
    histIdx.current--
    applyRows(history.current[histIdx.current].rows, false)
    setSnack({ msg: `Undo: ${history.current[histIdx.current].desc}`, sev: 'info' })
  }, [applyRows])

  const redo = useCallback(() => {
    if (histIdx.current >= history.current.length - 1) return
    histIdx.current++
    applyRows(history.current[histIdx.current].rows, false)
    setSnack({ msg: `Redo: ${history.current[histIdx.current].desc}`, sev: 'info' })
  }, [applyRows])

  // ── Workspace load (warehouse → staging overlay) ─────────────────
  const loadWorkspace = useCallback(() => {
    if (!companyId) return
    setLoading(true)
    fetchWorkspace(companyId, mode, reportType)
      .then((data: any) => {
        const initial = data.rows.map((r: GRow) => ({
          ...r, _depth:0, _hasChildren:false, _collapsed:false
        }))
        setYears(data.years)
        rowsRef.current    = initial
        origRowsRef.current = JSON.parse(JSON.stringify(initial))
        setRows(initial)
        history.current   = [{ rows: JSON.parse(JSON.stringify(initial)), desc: 'Load' }]
        histIdx.current   = 0
        setDirty(false)
        setHadDeletes(false)
        setModifiedCells(new Set())
        setSelRange(null)
        selCellsRef.current = new Set()

        // Surface warehouse-layer errors as non-blocking warnings
        if (data.warehouse_error) {
          setSnack({ msg: `Warehouse warning: ${data.warehouse_error}`, sev: 'warning' })
        }

        // Auto-freeze if any data loaded; blank companies open in edit mode
        if (data.has_warehouse_data || data.has_any_data) {
          setFreezeMode('frozen')
          setDataSource(data.has_warehouse_data ? 'warehouse' : 'staged')
          if (!data.warehouse_error) {
            const src = data.has_warehouse_data ? 'warehouse' : 'staging'
            const filled = (data.rows as GRow[]).filter((r: GRow) => r._source !== 'empty').length
            setSnack({ msg: `Loaded ${filled} rows from ${src}`, sev: 'success' })
          }
        } else {
          setFreezeMode('editing')
          setDataSource('empty')
          if (!data.warehouse_error) {
            setSnack({ msg: 'No warehouse data — enter values and click Analyze', sev: 'info' })
          }
        }
      })
      .catch((e: any) => {
        const status = e?.response?.status
        const msg = status === 404
          ? 'Company not found in warehouse — enter data manually'
          : status === 500
            ? `Workspace load error: ${e?.response?.data?.detail || 'server error'}`
            : 'Cannot reach backend — is the server running?'
        setSnack({ msg, sev: 'error' })
        // Still open blank template so analyst can work
        setFreezeMode('editing')
        setDataSource('empty')
      })
      .finally(() => setLoading(false))
  }, [companyId, mode, reportType])

  useEffect(() => { loadWorkspace() }, [loadWorkspace])

  // ── Freeze / Unfreeze ────────────────────────────────────────────
  const handleUnfreeze = () => {
    setFreezeMode('editing')
    setSnack({ msg: '🔓 Edit mode — changes will create a new version on save', sev: 'info' })
  }

  const handleDiscard = () => {
    rowsRef.current = JSON.parse(JSON.stringify(origRowsRef.current))
    setRows([...rowsRef.current])
    history.current = [{ rows: JSON.parse(JSON.stringify(origRowsRef.current)), desc: 'Discarded changes' }]
    histIdx.current = 0
    setDirty(false)
    setHadDeletes(false)
    setModifiedCells(new Set())
    setFreezeMode('frozen')
    setDiscardDlg(false)
    setSnack({ msg: 'Changes discarded', sev: 'info' })
  }

  // ── Selection display ────────────────────────────────────────────
  const updateSelectionDisplay = useCallback((range: SelRange | null, yrs: string[]) => {
    selCellsRef.current = rangeToSet(range, yrs)
    gridRef.current?.api?.refreshCells({ force: true, suppressFlash: true })
  }, [])

  // ── Mouse selection ──────────────────────────────────────────────
  const onCellMouseDown = useCallback((e: any) => {
    if (freezeMode === 'frozen') return
    const col = e.column?.getColId?.()
    if (!col || !yearsRef.current.includes(col)) return
    const row = e.rowIndex ?? 0
    isDragging.current = true
    dragStart.current  = { row, col }
    const range = { start: { row, col }, end: { row, col } }
    setSelRange(range)
    updateSelectionDisplay(range, yearsRef.current)
  }, [freezeMode, updateSelectionDisplay])

  const onCellMouseOver = useCallback((e: any) => {
    if (!isDragging.current || !dragStart.current) return
    const col = e.column?.getColId?.()
    if (!col || !yearsRef.current.includes(col)) return
    const row = e.rowIndex ?? 0
    const range = { start: dragStart.current, end: { row, col } }
    setSelRange(range)
    updateSelectionDisplay(range, yearsRef.current)
  }, [updateSelectionDisplay])

  useEffect(() => {
    const onUp = () => { isDragging.current = false }
    window.addEventListener('mouseup', onUp)
    return () => window.removeEventListener('mouseup', onUp)
  }, [])

  // ── Tree ops ─────────────────────────────────────────────────────
  const onToggle = useCallback((item: string) => {
    const u = rowsRef.current.map(r => r.financial_item===item ? {...r,_collapsed:!r._collapsed} : r)
    rowsRef.current = u; setRows([...u])
  }, [])

  const onRename = useCallback((oldName: string, newName: string) => {
    const t = newName.trim()
    if (!t || t===oldName) return
    if (rowsRef.current.some(r => r.financial_item===t)) { setSnack({msg:'Name exists',sev:'error'}); return }
    snapshot('Rename', rowsRef.current)
    applyRows(rowsRef.current.map(r => ({
      ...r,
      financial_item: r.financial_item===oldName ? t : r.financial_item,
      parent_item:    r.parent_item===oldName    ? t : r.parent_item,
    })))
  }, [applyRows])

  // ── Cell value change ─────────────────────────────────────────────
  const onCellValueChanged = useCallback((e: CellValueChangedEvent) => {
    if (freezeMode === 'frozen') return
    snapshot('Edit cell', rowsRef.current)
    const colId = e.column.getColId()
    let u = rowsRef.current.map((r: GRow) =>
      r.financial_item===e.data.financial_item && r.category===e.data.category
        ? { ...r, [colId]: e.newValue, _modified: true }
        : r
    )
    const changed = u.find(r => r.financial_item===e.data.financial_item)
    if (changed?.parent_item) {
      const parent = u.find(r => r.financial_item===changed.parent_item)
      if (parent) u = u.map(r => r.financial_item===parent.financial_item ? sumChildren(u, parent, years) : r)
    }
    // Track which cells were modified
    setModifiedCells(prev => new Set(prev).add(`${e.rowIndex}::${colId}`))
    applyRows(u)
  }, [freezeMode, years, applyRows])

  // ── Delete range ─────────────────────────────────────────────────
  const deleteRange = useCallback((range: SelRange | null) => {
    if (freezeMode === 'frozen') return
    if (!range) return
    const r0 = Math.min(range.start.row, range.end.row)
    const r1 = Math.max(range.start.row, range.end.row)
    const c0i = Math.min(years.indexOf(range.start.col), years.indexOf(range.end.col))
    const c1i = Math.max(years.indexOf(range.start.col), years.indexOf(range.end.col))
    if (c0i < 0 || c1i < 0) return
    const colsToClear = years.slice(c0i, c1i + 1)
    const filtered    = rowsRef.current.filter(r => r.category === CATS[activeTab])
    const rowKeys     = new Set(filtered.slice(r0, r1 + 1).map(r => r.financial_item))
    if (!rowKeys.size) return
    const total = rowKeys.size * colsToClear.length
    snapshot('Delete range', rowsRef.current)
    setHadDeletes(true)
    const u = rowsRef.current.map(r => {
      if (!rowKeys.has(r.financial_item) || r.category !== CATS[activeTab]) return r
      const patch = { ...r, _modified: true }
      colsToClear.forEach(col => { patch[col] = null })
      return patch
    })
    applyRows(u)
    setSnack({ msg: `Cleared ${total} cell${total>1?'s':''}`, sev: 'info' })
  }, [freezeMode, years, activeTab, applyRows])

  // ── Copy ─────────────────────────────────────────────────────────
  const copyRange = useCallback((range: SelRange | null) => {
    if (!range) return
    const r0 = Math.min(range.start.row, range.end.row)
    const r1 = Math.max(range.start.row, range.end.row)
    const c0 = Math.min(years.indexOf(range.start.col), years.indexOf(range.end.col))
    const c1 = Math.max(years.indexOf(range.start.col), years.indexOf(range.end.col))
    if (c0 < 0) return
    const filtered = rowsRef.current.filter(r => r.category === CATS[activeTab])
    const lines: string[] = []
    for (let ri = r0; ri <= r1; ri++) {
      const row = filtered[ri]; if (!row) continue
      const cells: string[] = []
      for (let ci = c0; ci <= c1; ci++) {
        const v = row[years[ci]]
        cells.push(v == null ? '' : unit==='crore' ? String(v/CRORE_TO_MN) : String(v))
      }
      lines.push(cells.join('\t'))
    }
    navigator.clipboard.writeText(lines.join('\n')).catch(() => {})
    setSnack({ msg: `Copied ${cellCount(range, years)} cells`, sev: 'info' })
  }, [years, activeTab, unit])

  // ── Paste ─────────────────────────────────────────────────────────
  useEffect(() => {
    const handler = (e: ClipboardEvent) => {
      if (freezeMode === 'frozen') return
      const text = e.clipboardData?.getData('text/plain')
      if (!text) return
      const api = gridRef.current?.api; if (!api) return
      let anchorRow = selRange?.start.row
      let anchorCol = selRange?.start.col
      if (anchorRow == null) {
        const fc = api.getFocusedCell()
        if (!fc || !years.includes(fc.column.getColId())) return
        anchorRow = fc.rowIndex ?? 0; anchorCol = fc.column.getColId()
      }
      if (anchorCol == null || !years.includes(anchorCol)) return
      e.preventDefault()
      snapshot('Paste', rowsRef.current)
      const pasteRows = text.trimEnd().split('\n').map((r: string) => r.split('\t'))
      const colStart  = years.indexOf(anchorCol)
      const colOrder  = years.slice(colStart)
      const filtered  = rowsRef.current.filter(r => r.category === CATS[activeTab])
      const u         = [...rowsRef.current]
      const newMod    = new Set(modifiedCells)
      pasteRows.forEach((pr: string[], ri: number) => {
        const target = filtered[anchorRow! + ri]; if (!target) return
        const mi = u.indexOf(target)
        pr.forEach((cell: string, ci: number) => {
          const col = colOrder[ci]; if (!col) return
          const num = parseFloat(cell.replace(/,/g,'').trim())
          const val = isNaN(num) ? null : (unit==='crore' ? num*CRORE_TO_MN : num)
          u[mi] = { ...u[mi], [col]: val, _modified: true }
          newMod.add(`${anchorRow! + ri}::${col}`)
        })
      })
      setModifiedCells(newMod)
      applyRows(u)
      const lr = Math.min(anchorRow! + pasteRows.length - 1, filtered.length - 1)
      const lc = years[Math.min(colStart + (Math.max(...pasteRows.map((r:string[])=>r.length)) - 1), years.length-1)]
      setSelRange({ start:{row:anchorRow!,col:anchorCol}, end:{row:lr,col:lc} })
      setSnack({ msg: `Pasted ${pasteRows.length}×${pasteRows[0]?.length||1} cells`, sev: 'success' })
    }
    window.addEventListener('paste', handler)
    return () => window.removeEventListener('paste', handler)
  }, [freezeMode, years, activeTab, unit, selRange, modifiedCells, applyRows])

  // ── Keyboard shortcuts ────────────────────────────────────────────
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName
      if (['INPUT','TEXTAREA'].includes(tag)) return
      if ((e.ctrlKey||e.metaKey) && e.key==='z') { e.preventDefault(); undo(); return }
      if ((e.ctrlKey||e.metaKey) && e.key==='y') { e.preventDefault(); redo(); return }
      if ((e.ctrlKey||e.metaKey) && e.key==='c') { e.preventDefault(); copyRange(selRange); return }
      if ((e.key==='Delete'||e.key==='Backspace') && freezeMode!=='frozen') {
        if (selRange) { e.preventDefault(); deleteRange(selRange); return }
        const api = gridRef.current?.api; if (!api) return
        const fc = api.getFocusedCell()
        if (!fc || !years.includes(fc.column.getColId())) return
        e.preventDefault()
        const col = fc.column.getColId(); const ri = fc.rowIndex ?? 0
        const filt = rowsRef.current.filter(r => r.category === CATS[activeTab])
        const target = filt[ri]; if (!target) return
        snapshot('Delete cell', rowsRef.current)
        setHadDeletes(true)
        applyRows(rowsRef.current.map(r =>
          r.financial_item===target.financial_item ? { ...r, [col]: null, _modified: true } : r
        ))
        return
      }
      if (e.shiftKey && ['ArrowRight','ArrowLeft','ArrowDown','ArrowUp'].includes(e.key)) {
        e.preventDefault()
        if (!selRange) return
        const { end } = selRange; const ci = years.indexOf(end.col)
        let nr = end.row, nc = ci
        if (e.key==='ArrowRight') nc = Math.min(ci+1, years.length-1)
        if (e.key==='ArrowLeft')  nc = Math.max(ci-1, 0)
        if (e.key==='ArrowDown')  nr = end.row + 1
        if (e.key==='ArrowUp')    nr = Math.max(end.row-1, 0)
        const newRange = { start: selRange.start, end: { row: nr, col: years[nc] } }
        setSelRange(newRange); updateSelectionDisplay(newRange, years)
      }
      if (e.key==='Escape') { setSelRange(null); updateSelectionDisplay(null, yearsRef.current) }
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [undo, redo, copyRange, deleteRange, selRange, years, activeTab, freezeMode, applyRows, updateSelectionDisplay])

  // ── Save ──────────────────────────────────────────────────────────
  const doSave = async (current: GRow[], explicit = true) => {
    if (!companyId) return
    setSaving(true)

    // Build what to save:
    // - Non-null values: normal rows
    // - Null values for warehouse items: NULL tombstones (explicit deletions)
    //   A tombstone tells the workspace overlay "user deleted this cell"
    //   so the warehouse value doesn't reappear on restart.
    const periodsWithData = new Set<string>()
    const toSave: InputRow[] = []

    // Build the set of (item, category, year) combinations that exist in warehouse
    // so we know which nulls need tombstones vs which are just blanks never entered
    // We write tombstones for ALL rows the user has seen in edit mode — this ensures
    // any cell they blanked out explicitly overrides warehouse on reload.

    for (const row of current) {
      for (const y of yearsRef.current) {
        if (row[y] != null) {
          // Real value — always save
          toSave.push({
            company_id: companyId, period_label: y,
            financial_item: row.financial_item, category: row.category,
            value: row[y], units: 'INR Million', sort_order: row.sort_order ?? 0,
            parent_item: row.parent_item || null,
          })
          periodsWithData.add(y)
        } else if (row._source === 'warehouse' || row._source === 'staged') {
          // NULL tombstone — user cleared a cell that previously had warehouse data.
          // Store NULL explicitly so workspace overlay knows to show blank, not warehouse value.
          toSave.push({
            company_id: companyId, period_label: y,
            financial_item: row.financial_item, category: row.category,
            value: null, units: 'INR Million', sort_order: row.sort_order ?? 0,
            parent_item: row.parent_item || null,
          })
        }
      }
    }

    // Periods where ALL values are now null/absent
    const periodsNowEmpty = yearsRef.current.filter(y => !periodsWithData.has(y))

    try {
      if (hadDeletes) {
        // 1. Clear SQLite staging for ALL periods (re-save remaining below)
        for (const y of yearsRef.current) {
          await api.delete(`/financial-input/${companyId}/${y}`).catch(() => {})
        }

        // 2. Deactivate warehouse rows for each TRULY EMPTY period
        //    This is the key fix: warehouse must reflect the deletion
        for (const y of periodsNowEmpty) {
          await api.post(`/calculate/invalidate/${companyId}?period=${y}`).catch(() => {})
        }

        // 3. If ALL periods empty, deactivate entire company in warehouse
        if (periodsWithData.size === 0) {
          await api.post(`/calculate/invalidate/${companyId}`).catch(() => {})
        }
      }

      if (toSave.length) {
        const res = await bulkSave(toSave)
        if (explicit) {
          setDirty(false)
          setHadDeletes(false)
          setFreezeMode('frozen')
          origRowsRef.current = JSON.parse(JSON.stringify(current))
          setModifiedCells(new Set())
          const emptyNote = periodsNowEmpty.length > 0
            ? ` · ${periodsNowEmpty.join(', ')} cleared from dashboard`
            : ''
          setSnack({ msg: `Saved ${res.saved} cells${emptyNote}`, sev: 'success' })
        }
      } else if (hadDeletes) {
        // All values deleted — warehouse deactivated above
        if (explicit) {
          setDirty(false)
          setHadDeletes(false)
          setFreezeMode('frozen')
          setDataSource('empty')
          setSnack({ msg: 'All data cleared — dashboard will show empty', sev: 'warning' })
        }
      }
    } catch (e: any) {
      setSnack({ msg: `Save failed: ${e?.message || 'unknown error'}`, sev: 'error' })
    } finally { setSaving(false) }
  }

  // ── Analyze ───────────────────────────────────────────────────────
  const handleAnalyze = async () => {
    setAnalyzing(true)
    try {
      await doSave(rowsRef.current, false)
      const period = filter.period || years[0] || 'FY25'
      await api.post(`/calculate/${companyId}/${period}`)
      setSnack({ msg: '✓ Analysis complete! Go to Dashboard →', sev: 'success' })
    } catch (e: any) {
      setSnack({ msg: e.response?.data?.detail || 'Analysis failed', sev: 'error' })
    } finally { setAnalyzing(false) }
  }

  // ── Column management ─────────────────────────────────────────────
  const handleAddYear = () => {
    const y = newYearVal.trim().toUpperCase()
    if (!y || years.includes(y)) return
    setYears([y, ...years])
    applyRows(rowsRef.current.map(r => ({ ...r, [y]: null })))
    setNewYearVal(''); setAddYearOpen(false)
  }

  const deleteColumn = (col: string) => {
    snapshot('Delete column', rowsRef.current)
    setYears(prev => prev.filter(y => y !== col))
    setHadDeletes(true)
    applyRows(rowsRef.current.map(r => { const n={...r}; delete n[col]; return n }))
    setDeleteColDlg(null)
  }

  // ── Row management ────────────────────────────────────────────────
  const insertRow = (parentName?: string) => {
    if (freezeMode === 'frozen') return
    const api   = gridRef.current?.api
    const sel   = api?.getSelectedNodes()
    const idx   = sel?.length ? (sel[0].rowIndex ?? 0) : 0
    const name  = `New Item ${Date.now().toString().slice(-4)}`
    const depth = parentName
      ? Math.min((rowsRef.current.find(r=>r.financial_item===parentName)?._depth||0)+1, MAX_DEPTH) : 0
    const blank: GRow = {
      financial_item: name, category: CATS[activeTab],
      units: 'INR Million', sort_order: idx+0.5,
      parent_item: parentName||null, _depth: depth, _hasChildren: false, _collapsed: false,
    }
    yearsRef.current.forEach(y => { blank[y] = null })
    snapshot('Insert row', rowsRef.current)
    const filt  = rowsRef.current.filter(r => r.category===CATS[activeTab])
    const after = filt[idx]
    const mi    = after ? rowsRef.current.indexOf(after) : rowsRef.current.length-1
    applyRows([...rowsRef.current.slice(0,mi+1), blank, ...rowsRef.current.slice(mi+1)])
    setTimeout(() => setEditingRow(name), 50)
  }

  const addChildRow = (parent: GRow) => {
    if (parent._depth >= MAX_DEPTH-1) { setSnack({msg:`Max depth ${MAX_DEPTH}`,sev:'info'}); return }
    applyRows(rowsRef.current.map(r => r.financial_item===parent.financial_item ? {...r,_hasChildren:true} : r))
    insertRow(parent.financial_item)
  }

  const deleteRow = (rowData?: GRow) => {
    if (freezeMode === 'frozen') return
    const targets = new Set<string>()
    if (rowData) {
      targets.add(rowData.financial_item)
      const addCh = (n: string) => rowsRef.current.filter(r=>r.parent_item===n).forEach(c => { targets.add(c.financial_item); addCh(c.financial_item) })
      addCh(rowData.financial_item)
    } else {
      gridRef.current?.api?.getSelectedNodes()?.forEach((n:any) => targets.add(n.data.financial_item))
    }
    if (!targets.size) return
    snapshot('Delete row', rowsRef.current)
    setHadDeletes(true)
    applyRows(rowsRef.current.filter(r => !targets.has(r.financial_item)))
  }

  const duplicateRow = (rowData: GRow) => {
    snapshot('Duplicate', rowsRef.current)
    const copy = { ...rowData, financial_item: `${rowData.financial_item} (copy)` }
    const idx  = rowsRef.current.indexOf(rowData)
    applyRows([...rowsRef.current.slice(0,idx+1), copy, ...rowsRef.current.slice(idx+1)])
  }

  // ── Column defs ───────────────────────────────────────────────────
  const colDefs: ColDef[] = useMemo(() => [
    {
      field: 'financial_item', headerName: 'Particulars', pinned: 'left',
      width: 280, editable: false, suppressSizeToFit: true,
      cellRenderer: (p: ICellRendererParams) => (
        <ParticularsRenderer {...p} onToggle={onToggle} onRename={onRename}
          editingRow={editingRow} setEditingRow={setEditingRow} frozen={freezeMode==='frozen'} />
      ),
    },
    {
      field: 'units', headerName: 'Units', width: 120, editable: freezeMode==='editing',
      cellEditor: 'agSelectCellEditor', cellEditorParams: { values: UNIT_OPTS },
      cellStyle: { color: '#64748B', fontSize: 12 },
    },
    ...years.map(y => ({
      field: y, headerName: y, width: 130, editable: freezeMode==='editing',
      headerComponent: (p: any) => (
        <Stack direction="row" alignItems="center" sx={{ height:'100%', gap:0.5 }}>
          <span style={{ fontSize:13, fontWeight:600, color:'#0B2545' }}>{y}</span>
          {freezeMode==='editing' && (
            <Box component="span" onClick={(e) => { e.stopPropagation(); setDeleteColDlg(y) }}
              sx={{ opacity:0, '.ag-header-cell:hover &':{opacity:1}, cursor:'pointer', color:'#DC2626', fontSize:11 }}
              title={`Delete ${y}`}>✕</Box>
          )}
        </Stack>
      ),
      cellStyle: (p: any) => {
        const key = `${p.rowIndex}::${y}`
        const selected = selCellsRef.current.has(key)
        const modified = modifiedCells.has(key)
        const hasVal   = p.value != null
        let bg = '#FFFBEB'
        if (freezeMode === 'frozen') {
          const src = p.data?._source as RowSource
          bg = src==='warehouse' ? BG.frozen_warehouse : src==='staged' ? BG.frozen_staged : BG.frozen_empty
        } else if (modified) {
          bg = BG.editing_modified
        } else if (hasVal) {
          bg = BG.editing_value
        }
        return {
          color: p.data?._depth>0 ? '#1E40AF' : '#1A56DB',
          fontWeight: 500,
          background: selected ? SEL_COLOR : bg,
          outline: selected ? SEL_BORDER : undefined,
          outlineOffset: '-1px',
          cursor: freezeMode==='frozen' ? 'default' : 'cell',
        }
      },
      valueFormatter: (p: any) => {
        if (p.value==null || p.value==='') return ''
        const v = unit==='crore' ? p.value/CRORE_TO_MN : p.value
        return Number(v).toLocaleString('en-IN',{maximumFractionDigits:2})
      },
      valueParser: (p: any) => {
        if (p.newValue===''||p.newValue==null) return null
        const num = parseFloat(String(p.newValue).replace(/,/g,''))
        if (isNaN(num)) return null
        return unit==='crore' ? num*CRORE_TO_MN : num
      },
    } as ColDef)),
  ], [years, unit, onToggle, onRename, editingRow, freezeMode, modifiedCells])

  // ── Tree rows ─────────────────────────────────────────────────────
  const treeRows = useMemo(() => {
    const cat   = rowsRef.current.filter(r => r.category===CATS[activeTab])
    const built = buildTree(cat)
    if (!search.trim()) return built
    const q = search.toLowerCase()
    return built.filter(r => r.financial_item.toLowerCase().includes(q))
  }, [rows, activeTab, search])

  const canUndo = histIdx.current > 0
  const canRedo = histIdx.current < history.current.length - 1
  const cnt     = cellCount(selRange, years)
  const frozen  = freezeMode === 'frozen'

  if (!companyId) return (
    <Box sx={{display:'flex',alignItems:'center',justifyContent:'center',height:400}}>
      <Typography color="text.secondary">Select a company in the top bar</Typography>
    </Box>
  )

  // ── Render ────────────────────────────────────────────────────────
  return (
    <Box>
      {/* Header */}
      <Stack direction="row" justifyContent="space-between" alignItems="flex-start" mb={1.5} flexWrap="wrap" gap={1}>
        <Box>
          <Typography variant="h5" fontWeight={700} color="#0B2545">Data Input</Typography>
          <Typography variant="body2" color="text.secondary">
            {companyId} ·{frozen
              ? ' Data loaded — click Unfreeze to edit'
              : ' Edit mode — drag to select, Ctrl+V to paste, Delete to clear'}
          </Typography>
        </Box>
        <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap">
          {dirty && !frozen && <Chip label="● Unsaved" size="small" color="warning" sx={{fontWeight:700}}/>}
          {cnt > 0 && <Chip label={`${cnt} selected`} size="small" sx={{bgcolor:'#EFF6FF',color:'#1D4ED8',fontWeight:600}}/>}
          <ToggleButtonGroup value={unit} exclusive size="small" onChange={(_,v)=>v&&setUnit(v)}
            sx={{'& .MuiToggleButton-root':{px:1.5,py:0.4,fontSize:12,textTransform:'none'}}}>
            <ToggleButton value="million">₹ Mn</ToggleButton>
            <ToggleButton value="crore">₹ Cr</ToggleButton>
          </ToggleButtonGroup>
        </Stack>
      </Stack>

      {/* Freeze/Unfreeze status bar */}
      {frozen && dataSource !== 'empty' ? (
        <Alert
          severity="info"
          icon={<LockIcon fontSize="small" />}
          sx={{ mb:1.5, py:0.5 }}
          action={
            <Button size="small" startIcon={<LockOpenIcon />}
              onClick={handleUnfreeze} variant="contained"
              sx={{bgcolor:'#0D9488','&:hover':{bgcolor:'#0F766E'}, ml:1}}>
              Unfreeze
            </Button>
          }
        >
          <strong>🔒 Data loaded from {dataSource === 'warehouse' ? 'warehouse' : 'staging'}.</strong>
          {' '}Read-only. Click Unfreeze to edit and create a new version.
        </Alert>
      ) : !frozen && (
        <Alert severity="warning" icon={<LockOpenIcon fontSize="small" />} sx={{ mb:1.5, py:0.5 }}
          action={
            <Stack direction="row" spacing={0.5}>
              <Button size="small" startIcon={<DiscardIcon />}
                onClick={() => setDiscardDlg(true)} color="warning" variant="outlined">Discard</Button>
              <Button size="small" startIcon={saving ? <CircularProgress size={12}/> : <SaveIcon />}
                onClick={() => doSave(rowsRef.current, true)} variant="contained"
                disabled={saving || !dirty} sx={{bgcolor:'#0D9488','&:hover':{bgcolor:'#0F766E'}}}>
                {saving ? 'Saving…' : 'Save & Freeze'}
              </Button>
            </Stack>
          }
        >
          <strong>🔓 Edit mode</strong> — grey = original, orange = modified.
          {hadDeletes && ' ⚠ Deleted cells will invalidate dashboard on save.'}
        </Alert>
      )}

      {/* Toolbar */}
      <Paper variant="outlined" sx={{mb:1,px:1.5,py:0.8,display:'flex',alignItems:'center',
        gap:0.5,flexWrap:'wrap',bgcolor:'#F8FAFC',borderColor:'#E2E8F0'}}>
        <Tooltip title="Undo (Ctrl+Z)"><span>
          <MuiIconButton size="small" onClick={undo} disabled={!canUndo||frozen}
            sx={{color:canUndo&&!frozen?'#0B2545':'#CBD5E1'}}><UndoIcon fontSize="small"/></MuiIconButton>
        </span></Tooltip>
        <Tooltip title="Redo (Ctrl+Y)"><span>
          <MuiIconButton size="small" onClick={redo} disabled={!canRedo||frozen}
            sx={{color:canRedo&&!frozen?'#0B2545':'#CBD5E1'}}><RedoIcon fontSize="small"/></MuiIconButton>
        </span></Tooltip>
        <Box sx={{width:1,height:20,bgcolor:'#E2E8F0',mx:0.5}}/>
        <Tooltip title="Copy (Ctrl+C)">
          <MuiIconButton size="small" onClick={()=>copyRange(selRange)} disabled={!selRange}
            sx={{color:'#0B2545'}}><ContentCopyIcon fontSize="small"/></MuiIconButton>
        </Tooltip>
        <Tooltip title="Clear selected (Delete)">
          <MuiIconButton size="small" onClick={()=>deleteRange(selRange)} disabled={!selRange||frozen}
            sx={{color:'#0B2545'}}><DeleteOutlineIcon fontSize="small"/></MuiIconButton>
        </Tooltip>
        <Box sx={{width:1,height:20,bgcolor:'#E2E8F0',mx:0.5}}/>
        <Button size="small" startIcon={<AddIcon sx={{fontSize:'14px !important'}}/>}
          onClick={()=>insertRow()} disabled={frozen}
          sx={{fontSize:11,textTransform:'none',color:frozen?'#CBD5E1':'#0B2545',px:1}} variant="text">Row</Button>
        <Button size="small" startIcon={<DeleteOutlineIcon sx={{fontSize:'14px !important'}}/>}
          onClick={()=>deleteRow()} disabled={frozen}
          sx={{fontSize:11,textTransform:'none',color:frozen?'#CBD5E1':'#DC2626',px:1}} variant="text">Row</Button>
        <Box sx={{width:1,height:20,bgcolor:'#E2E8F0',mx:0.5}}/>
        <Button size="small" startIcon={<AddIcon sx={{fontSize:'14px !important'}}/>}
          onClick={()=>setAddYearOpen(true)} disabled={frozen}
          sx={{fontSize:11,textTransform:'none',color:frozen?'#CBD5E1':'#0B2545',px:1}} variant="text">Column</Button>
        <Box sx={{flex:1}}/>
        <Button variant={frozen?'outlined':'contained'} size="small"
          startIcon={analyzing?<CircularProgress size={12} color="inherit"/>:<PlayArrowIcon/>}
          onClick={handleAnalyze} disabled={analyzing}
          sx={{fontSize:12,textTransform:'none',bgcolor:frozen?undefined:'#0D9488',
            '&:hover':{bgcolor:frozen?undefined:'#0F766E'}}}>
          {analyzing?'Analyzing…':'Analyze'}
        </Button>
        <Box sx={{flex:0,width:8}}/>
        <TextField size="small" placeholder="Search rows…" value={search}
          onChange={e=>setSearch(e.target.value)}
          InputProps={{
            startAdornment:<InputAdornment position="start"><SearchIcon sx={{fontSize:16,color:'#94A3B8'}}/></InputAdornment>,
            endAdornment:search?<InputAdornment position="end"><MuiIconButton size="small" onClick={()=>setSearch('')}><ClearIcon sx={{fontSize:14}}/></MuiIconButton></InputAdornment>:null,
          }}
          sx={{width:170,'& .MuiInputBase-root':{fontSize:12,height:32}}}
        />
      </Paper>

      {/* Tabs */}
      <Paper sx={{mb:1}}>
        <Tabs value={activeTab} onChange={(_,v)=>setActiveTab(v)}
          sx={{borderBottom:1,borderColor:'divider',minHeight:38}}>
          {CATS.map(cat => <Tab key={cat} label={cat}
            sx={{fontWeight:600,fontSize:12,minHeight:38,textTransform:'none',py:0.5}}/>)}
        </Tabs>
      </Paper>

      {/* Grid */}
      {loading
        ? <Box sx={{display:'flex',flexDirection:'column',alignItems:'center',py:6,gap:2}}>
            <CircularProgress/>
            <Typography color="text.secondary" fontSize={13}>Loading workspace from warehouse…</Typography>
          </Box>
        : (
          <Paper sx={{height:520,overflow:'hidden',borderRadius:1.5,
            opacity: frozen ? 0.92 : 1,
            transition: 'opacity 0.2s',
          }}>
            <div className="ag-theme-alpine" style={{height:'100%',width:'100%'}}>
              <AgGridReact
                ref={(p:any) => { if(p) gridRef.current = p }}
                rowData={treeRows}
                columnDefs={colDefs}
                defaultColDef={{resizable:true}}
                onCellValueChanged={onCellValueChanged}
                onCellContextMenu={(e:any) => setCtxMenu({x:e.event?.clientX||0,y:e.event?.clientY||0,rowData:e.data})}
                onCellMouseDown={onCellMouseDown}
                onCellMouseOver={onCellMouseOver}
                suppressClipboardPaste={true}
                enableCellChangeFlash={!frozen}
                undoRedoCellEditing={false}
                rowSelection="multiple"
                rowHeight={34} headerHeight={40} animateRows
                getRowId={(p:any) => `${p.data.financial_item}__${p.data.category}`}
                getRowStyle={(p:any) => {
                  const item = p.data?.financial_item||''
                  const bold = ['Total Cost','Revenue from Operations','Total Income','Net Worth','Total Assets'].includes(item)
                  if (bold) return {background:'#F0F9FF',fontWeight:700}
                  if (p.data?._depth===1) return {background:'#FAFAFA'}
                  if (p.data?._depth===2) return {background:'#F5F5F5'}
                  return {}
                }}
              />
            </div>
          </Paper>
        )
      }
      {saving && <LinearProgress sx={{mt:0.5, borderRadius:1}}/>}

      {/* Footer */}
      <Stack direction="row" justifyContent="space-between" mt={0.8}>
        <Typography variant="caption" color="text.secondary">
          {treeRows.length} rows · {years.length} periods
          {cnt>0&&` · ${cnt} selected`}
          {hadDeletes&&!frozen&&<span style={{color:'#D97706'}}> · ⚠ Has deletions</span>}
        </Typography>
        <Stack direction="row" spacing={1}>
          {/* Legend */}
          {frozen && dataSource!=='empty' && (
            <Stack direction="row" spacing={0.5} alignItems="center">
              <Box sx={{width:10,height:10,bgcolor:BG.frozen_warehouse,border:'1px solid #CBD5E1',borderRadius:0.5}}/>
              <Typography variant="caption" color="text.secondary" sx={{fontSize:10}}>Warehouse</Typography>
              <Box sx={{width:10,height:10,bgcolor:BG.frozen_staged,border:'1px solid #CBD5E1',borderRadius:0.5}}/>
              <Typography variant="caption" color="text.secondary" sx={{fontSize:10}}>Staged</Typography>
            </Stack>
          )}
          {!frozen && (
            <Stack direction="row" spacing={0.5} alignItems="center">
              <Box sx={{width:10,height:10,bgcolor:BG.editing_value,border:'1px solid #CBD5E1',borderRadius:0.5}}/>
              <Typography variant="caption" color="text.secondary" sx={{fontSize:10}}>Original</Typography>
              <Box sx={{width:10,height:10,bgcolor:BG.editing_modified,border:'1px solid #CBD5E1',borderRadius:0.5}}/>
              <Typography variant="caption" color="text.secondary" sx={{fontSize:10}}>Modified</Typography>
            </Stack>
          )}
        </Stack>
      </Stack>

      {/* Context menu */}
      <Menu open={!!ctxMenu} onClose={()=>setCtxMenu(null)}
        anchorReference="anchorPosition"
        anchorPosition={ctxMenu?{top:ctxMenu.y,left:ctxMenu.x}:undefined}
        PaperProps={{sx:{minWidth:200,boxShadow:'0 4px 20px rgba(0,0,0,0.12)',borderRadius:1.5}}}>
        <Box sx={{px:1.5,py:0.5}}>
          <Typography variant="caption" color="text.secondary" fontWeight={700}>
            {ctxMenu?.rowData?.financial_item}
          </Typography>
        </Box>
        <MuiDivider/>
        <MenuItem onClick={()=>{if(!frozen){setEditingRow(ctxMenu!.rowData.financial_item)}setCtxMenu(null)}} dense disabled={frozen}>
          <ListItemIcon><span style={{fontSize:14}}>✏️</span></ListItemIcon>
          <ListItemText>Rename</ListItemText>
        </MenuItem>
        <MenuItem onClick={()=>{addChildRow(ctxMenu!.rowData);setCtxMenu(null)}} dense
          disabled={frozen||ctxMenu?.rowData?._depth>=MAX_DEPTH-1}>
          <ListItemIcon><SubdirectoryArrowRightIcon fontSize="small" sx={{color:'#0B2545'}}/></ListItemIcon>
          <ListItemText>Add child row</ListItemText>
        </MenuItem>
        <MenuItem onClick={()=>{duplicateRow(ctxMenu!.rowData);setCtxMenu(null)}} dense disabled={frozen}>
          <ListItemIcon><ContentCopyIcon fontSize="small"/></ListItemIcon>
          <ListItemText>Duplicate row</ListItemText>
        </MenuItem>
        {cnt>0&&[
          <MuiDivider key="d"/>,
          <MenuItem key="clr" onClick={()=>{deleteRange(selRange);setCtxMenu(null)}} dense disabled={frozen}>
            <ListItemIcon><DeleteOutlineIcon fontSize="small" sx={{color:'#DC2626'}}/></ListItemIcon>
            <ListItemText sx={{color:'#DC2626'}}>Clear {cnt} cells</ListItemText>
          </MenuItem>
        ]}
        <MuiDivider/>
        <MenuItem onClick={()=>{deleteRow(ctxMenu!.rowData);setCtxMenu(null)}} dense
          sx={{color:'#DC2626'}} disabled={frozen}>
          <ListItemIcon><DeleteOutlineIcon fontSize="small" sx={{color:'#DC2626'}}/></ListItemIcon>
          <ListItemText>Delete row</ListItemText>
        </MenuItem>
      </Menu>

      {/* Add Year */}
      <Dialog open={addYearOpen} onClose={()=>setAddYearOpen(false)} maxWidth="xs" fullWidth>
        <DialogTitle sx={{pb:1}}>Add Period Column</DialogTitle>
        <DialogContent>
          <TextField autoFocus fullWidth label="Period" size="small" value={newYearVal}
            onChange={e=>setNewYearVal(e.target.value)} placeholder="e.g. FY26 or Q1FY26"
            helperText="Adds a blank column — fill values then Analyze" sx={{mt:1}}/>
        </DialogContent>
        <DialogActions sx={{px:2,pb:2}}>
          <Button onClick={()=>setAddYearOpen(false)}>Cancel</Button>
          <Button onClick={handleAddYear} variant="contained" disabled={!newYearVal.trim()}>Add</Button>
        </DialogActions>
      </Dialog>

      {/* Delete Column */}
      <Dialog open={!!deleteColDlg} onClose={()=>setDeleteColDlg(null)} maxWidth="xs" fullWidth>
        <DialogTitle sx={{color:'#DC2626',pb:1}}>Delete Column {deleteColDlg}?</DialogTitle>
        <DialogContent>
          <Typography variant="body2">
            All values in <strong>{deleteColDlg}</strong> will be removed. This invalidates the dashboard.
          </Typography>
        </DialogContent>
        <DialogActions sx={{px:2,pb:2}}>
          <Button onClick={()=>setDeleteColDlg(null)}>Cancel</Button>
          <Button color="error" variant="contained" onClick={()=>deleteColDlg&&deleteColumn(deleteColDlg)}>Delete</Button>
        </DialogActions>
      </Dialog>

      {/* Discard Dialog */}
      <Dialog open={discardDlg} onClose={()=>setDiscardDlg(false)} maxWidth="xs" fullWidth>
        <DialogTitle sx={{color:'#D97706',pb:1}}>Discard changes?</DialogTitle>
        <DialogContent>
          <Typography variant="body2">
            All unsaved edits will be lost and the table will revert to the last saved state.
          </Typography>
        </DialogContent>
        <DialogActions sx={{px:2,pb:2}}>
          <Button onClick={()=>setDiscardDlg(false)}>Keep editing</Button>
          <Button color="warning" variant="contained" onClick={handleDiscard}>Discard</Button>
        </DialogActions>
      </Dialog>

      <Snackbar open={!!snack} autoHideDuration={4000} onClose={()=>setSnack(null)}
        anchorOrigin={{vertical:'bottom',horizontal:'right'}}>
        <Alert severity={snack?.sev} onClose={()=>setSnack(null)} variant="filled">{snack?.msg}</Alert>
      </Snackbar>
    </Box>
  )
}
