import React, { useState, useMemo } from 'react'
import {
  Box, Drawer, AppBar, Toolbar, Typography, List, ListItem,
  ListItemButton, ListItemIcon, ListItemText, Select, MenuItem,
  FormControl, Divider, Button, Dialog, DialogTitle, DialogContent,
  DialogActions, TextField, Stack, Chip, Avatar, IconButton,
  ToggleButton, ToggleButtonGroup, Paper, Tooltip, Badge
} from '@mui/material'
import { useNavigate, useLocation } from 'react-router-dom'
import TableChartIcon    from '@mui/icons-material/TableChart'
import DashboardIcon     from '@mui/icons-material/Dashboard'
import FileDownloadIcon  from '@mui/icons-material/FileDownload'
import AddBusinessIcon   from '@mui/icons-material/AddBusiness'
import BarChartIcon      from '@mui/icons-material/BarChart'
import GroupsIcon        from '@mui/icons-material/Groups'
import InsightsIcon      from '@mui/icons-material/Insights'
import AddIcon           from '@mui/icons-material/Add'
import DeleteIcon        from '@mui/icons-material/Delete'
import TrendingUpIcon    from '@mui/icons-material/TrendingUp'
import { useFilter, getPeriods } from '../../App'
import { createCompany } from '../../api/client'

// ─── Theme tokens ─────────────────────────────────────────────────────────────
const C = {
  navBg:      '#0F1C2E',   // deep navy
  navBg2:     '#162336',   // slightly lighter for cards
  orange:     '#F97316',   // accent — selected state
  orangeSoft: '#FFF0E5',   // light orange tint
  lightBlue:  '#38BDF8',   // hover accent
  white:      '#FFFFFF',
  muted:      'rgba(255,255,255,0.45)',
  border:     'rgba(255,255,255,0.08)',
  cardBg:     'rgba(255,255,255,0.05)',
  cardHover:  'rgba(56,189,248,0.10)',   // light blue hover
}

const DRAWER_W = 220

const NAV = [
  { path: '/input',     label: 'Data Input',        icon: <TableChartIcon />,   badge: 0 },
  { path: '/dashboard', label: 'Dashboard',          icon: <DashboardIcon />,    badge: 0 },
  { path: '/peer',      label: 'Peer Comparison',    icon: <GroupsIcon />,       badge: 0 },
  { path: '/advanced',  label: 'Advanced Analytics', icon: <InsightsIcon />,     badge: 0 },
  { path: '/export',    label: 'Export',             icon: <FileDownloadIcon />, badge: 0 },
]

const emptySector = () => ({ sector: '', sub_sector: '' })

export default function AppShell({ children }: { children: React.ReactNode }) {
  const nav = useNavigate()
  const loc = useLocation()
  const { filter, setFilter, companies, refreshCompanies } = useFilter()

  const [addOpen, setAddOpen]       = useState(false)
  const [newCo, setNewCo]           = useState({ company_id: '', company_name: '', ticker: '' })
  const [sectorRows, setSectorRows] = useState([emptySector()])
  const [saving, setSaving]         = useState(false)

  const periods = useMemo(() => getPeriods(filter.periodType), [filter.periodType])

  const handlePeriodType = (val: 'annual' | 'quarterly') => {
    setFilter({ periodType: val, period: getPeriods(val)[0] })
  }

  const handleAdd = async () => {
    if (!newCo.company_id || !newCo.company_name) return
    setSaving(true)
    try {
      await createCompany({
        ...newCo,
        company_id: newCo.company_id.toUpperCase(),
        sectors: sectorRows.filter(s => s.sector.trim()),
      })
      setAddOpen(false)
      setNewCo({ company_id: '', company_name: '', ticker: '' })
      setSectorRows([emptySector()])
      refreshCompanies()
    } catch (e: any) {
      alert('Error: ' + (e.response?.data?.detail || e.message))
    } finally { setSaving(false) }
  }

  const selectedCo = companies.find(c => c.company_id === filter.company)

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh' }}>

      {/* ════════════════ SIDEBAR ════════════════ */}
      <Drawer variant="permanent" sx={{
        width: DRAWER_W, flexShrink: 0,
        '& .MuiDrawer-paper': {
          width: DRAWER_W,
          bgcolor: C.navBg,
          border: 'none',
          overflowX: 'hidden',
          display: 'flex',
          flexDirection: 'column',
        }
      }}>
        {/* ── Logo ── */}
        <Box sx={{ px: 2.5, py: 2.5, display: 'flex', alignItems: 'center', gap: 1.5 }}>
          <Box sx={{
            width: 36, height: 36, borderRadius: 1.5,
            background: 'linear-gradient(135deg, #F97316 0%, #FB923C 100%)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 4px 12px rgba(249,115,22,0.4)',
          }}>
            <TrendingUpIcon sx={{ color: 'white', fontSize: 20 }} />
          </Box>
          <Box>
            <Typography fontWeight={800} color="white" fontSize={15} lineHeight={1.2} letterSpacing={-0.3}>
              FinIntel
            </Typography>
            <Typography fontSize={9.5} sx={{ color: C.muted, letterSpacing: 0.5 }}>
              ANALYTICS PLATFORM
            </Typography>
          </Box>
        </Box>

        <Box sx={{ borderBottom: `1px solid ${C.border}`, mx: 2, mb: 1.5 }} />

        {/* ── Company selector ── */}
        <Box sx={{ px: 2, mb: 1.5 }}>
          <Typography sx={{ color: C.muted, fontSize: 9, fontWeight: 700, letterSpacing: 1.2, mb: 0.8, textTransform: 'uppercase' }}>
            Company
          </Typography>
          <Box sx={{
            bgcolor: C.cardBg, border: `1px solid ${C.border}`,
            borderRadius: 1.5, p: 1.2, cursor: 'pointer',
            transition: 'background 0.15s',
            '&:hover': { bgcolor: C.cardHover, borderColor: `${C.lightBlue}40` },
          }}>
            <FormControl fullWidth size="small">
              <Select
                value={filter.company}
                onChange={e => setFilter({ company: e.target.value })}
                variant="standard"
                disableUnderline
                sx={{
                  color: 'white', fontWeight: 600, fontSize: 13,
                  '& .MuiSelect-icon': { color: C.muted },
                  '& .MuiSelect-select': { py: 0 },
                }}
              >
                {companies.map(c => (
                  <MenuItem key={c.company_id} value={c.company_id}>
                    <Stack>
                      <Typography fontSize={13} fontWeight={700}>{c.company_id}</Typography>
                      <Typography fontSize={10} color="text.secondary" noWrap sx={{ maxWidth: 160 }}>{c.company_name}</Typography>
                    </Stack>
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            {selectedCo && (
              <Typography fontSize={10} noWrap sx={{ color: C.muted, mt: 0.3 }}>
                {selectedCo.sectors_display || 'No sector'}
              </Typography>
            )}
          </Box>
          <Button
            startIcon={<AddBusinessIcon sx={{ fontSize: '13px !important' }} />}
            onClick={() => setAddOpen(true)} fullWidth size="small"
            sx={{
              mt: 0.8, color: C.orange, borderColor: `${C.orange}50`, fontSize: 11,
              textTransform: 'none', borderRadius: 1.5,
              '&:hover': { bgcolor: `${C.orange}15`, borderColor: C.orange },
              transition: 'all 0.15s',
            }}
            variant="outlined"
          >
            Add Company
          </Button>
        </Box>

        <Box sx={{ borderBottom: `1px solid ${C.border}`, mx: 2, mb: 1 }} />

        {/* ── Navigation ── */}
        <List sx={{ px: 1.5, flexGrow: 1 }}>
          {NAV.map(item => {
            const active = loc.pathname === item.path
            return (
              <ListItem key={item.path} disablePadding sx={{ mb: 0.4 }}>
                <ListItemButton
                  onClick={() => nav(item.path)}
                  sx={{
                    borderRadius: 1.5,
                    py: 0.9, px: 1.2,
                    transition: 'all 0.15s cubic-bezier(0.4,0,0.2,1)',
                    bgcolor: active ? `${C.orange}22` : 'transparent',
                    borderLeft: active ? `3px solid ${C.orange}` : '3px solid transparent',
                    '&:hover': {
                      bgcolor: active ? `${C.orange}28` : C.cardHover,
                      borderLeftColor: active ? C.orange : `${C.lightBlue}80`,
                      '& .nav-icon': { color: active ? C.orange : C.lightBlue },
                    },
                  }}
                >
                  <ListItemIcon
                    className="nav-icon"
                    sx={{
                      color: active ? C.orange : C.muted,
                      minWidth: 32,
                      transition: 'color 0.15s',
                    }}
                  >
                    {React.cloneElement(item.icon as React.ReactElement, { sx: { fontSize: 18 } })}
                  </ListItemIcon>
                  <ListItemText
                    primary={item.label}
                    primaryTypographyProps={{
                      fontSize: 13,
                      fontWeight: active ? 700 : 400,
                      color: active ? 'white' : C.muted,
                    }}
                  />
                  {active && (
                    <Box sx={{ width: 6, height: 6, borderRadius: '50%', bgcolor: C.orange, ml: 0.5 }} />
                  )}
                </ListItemButton>
              </ListItem>
            )
          })}
        </List>

        {/* ── Bottom info ── */}
        <Box sx={{ p: 2, borderTop: `1px solid ${C.border}` }}>
          <Stack direction="row" alignItems="center" spacing={1}>
            <Box sx={{ width: 6, height: 6, borderRadius: '50%', bgcolor: '#22C55E' }} />
            <Typography fontSize={10} color={C.muted}>System ready</Typography>
          </Stack>
          <Typography fontSize={9} sx={{ color: 'rgba(255,255,255,0.18)', mt: 0.3 }}>
            Cost Structure · Altman Z · Peer Analysis
          </Typography>
        </Box>
      </Drawer>

      {/* ════════════════ MAIN AREA ════════════════ */}
      <Box sx={{ flexGrow: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', bgcolor: '#F8FAFC' }}>

        {/* ── Top filter bar ── */}
        <Paper elevation={0} sx={{
          borderBottom: '1px solid #E2E8F0', borderRadius: 0,
          px: 3, py: 1, bgcolor: 'white',
        }}>
          <Stack direction="row" spacing={2} alignItems="center" flexWrap="wrap">
            {/* Period type */}
            <ToggleButtonGroup
              value={filter.periodType} exclusive size="small"
              onChange={(_, v) => v && handlePeriodType(v)}
              sx={{
                '& .MuiToggleButton-root': {
                  px: 1.8, py: 0.5, fontSize: 12, textTransform: 'none',
                  border: '1px solid #E2E8F0', color: '#475569',
                  '&.Mui-selected': { bgcolor: '#0F1C2E', color: 'white', borderColor: '#0F1C2E' },
                }
              }}
            >
              <ToggleButton value="annual">Annual</ToggleButton>
              <ToggleButton value="quarterly">Quarterly</ToggleButton>
            </ToggleButtonGroup>

            {/* Period */}
            <FormControl size="small" sx={{ minWidth: 110 }}>
              <Select
                value={filter.period}
                onChange={e => setFilter({ period: e.target.value })}
                sx={{ fontSize: 13, '& .MuiOutlinedInput-notchedOutline': { borderColor: '#E2E8F0' } }}
              >
                {periods.map(p => <MenuItem key={p} value={p} sx={{ fontSize: 13 }}>{p}</MenuItem>)}
              </Select>
            </FormControl>

            {/* Report type */}
            <ToggleButtonGroup
              value={filter.reportType} exclusive size="small"
              onChange={(_, v) => v && setFilter({ reportType: v })}
              sx={{
                '& .MuiToggleButton-root': {
                  px: 1.8, py: 0.5, fontSize: 12, textTransform: 'none',
                  border: '1px solid #E2E8F0', color: '#475569',
                  '&.Mui-selected': { bgcolor: '#F97316', color: 'white', borderColor: '#F97316' },
                }
              }}
            >
              <ToggleButton value="consolidated">Consolidated</ToggleButton>
              <ToggleButton value="standalone">Standalone</ToggleButton>
            </ToggleButtonGroup>

            <Box sx={{ flexGrow: 1 }} />

            {/* Active filter chips */}
            <Chip
              label={filter.company || '—'} size="small"
              sx={{ bgcolor: '#EFF6FF', color: '#1D4ED8', fontWeight: 700, fontSize: 11, height: 24 }}
            />
            <Chip
              label={filter.period} size="small"
              sx={{ bgcolor: '#FFF7ED', color: '#C2410C', fontWeight: 700, fontSize: 11, height: 24 }}
            />
            <Chip
              label={filter.reportType === 'consolidated' ? 'Consol.' : 'Standalone'} size="small"
              sx={{ bgcolor: '#F0FDF4', color: '#166534', fontWeight: 700, fontSize: 11, height: 24 }}
            />
          </Stack>
        </Paper>

        {/* ── Page content ── */}
        <Box sx={{ flexGrow: 1, overflow: 'auto', p: 3 }}>
          {children}
        </Box>
      </Box>

      {/* ════════ Add Company Dialog ════════ */}
      <Dialog open={addOpen} onClose={() => setAddOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ bgcolor: '#0F1C2E', color: 'white', py: 2, fontSize: 16 }}>
          Add New Company
        </DialogTitle>
        <DialogContent sx={{ mt: 2 }}>
          <Stack spacing={2} sx={{ mt: 0.5 }}>
            <Stack direction="row" spacing={1.5}>
              <TextField label="Company ID *" value={newCo.company_id} size="small"
                onChange={e => setNewCo({ ...newCo, company_id: e.target.value.toUpperCase() })}
                placeholder="e.g. CIPLA" sx={{ flex: 1 }} />
              <TextField label="Ticker" value={newCo.ticker} size="small"
                onChange={e => setNewCo({ ...newCo, ticker: e.target.value })}
                placeholder="e.g. CIPLA.NS" sx={{ flex: 1 }} />
            </Stack>
            <TextField label="Company Name *" value={newCo.company_name} size="small"
              onChange={e => setNewCo({ ...newCo, company_name: e.target.value })}
              placeholder="e.g. Cipla Ltd" fullWidth />
            <Box>
              <Stack direction="row" justifyContent="space-between" alignItems="center" mb={0.5}>
                <Typography variant="caption" fontWeight={700} color="text.secondary">SECTORS</Typography>
                <Button size="small" startIcon={<AddIcon />}
                  onClick={() => setSectorRows(r => [...r, emptySector()])}
                  sx={{ fontSize: 11, textTransform: 'none' }}>
                  Add Sector
                </Button>
              </Stack>
              {sectorRows.map((s, i) => (
                <Stack key={i} direction="row" spacing={1} mb={1} alignItems="center">
                  <TextField label="Sector" value={s.sector} size="small" placeholder="Pharma"
                    onChange={e => setSectorRows(r => r.map((x, j) => j===i ? {...x, sector: e.target.value} : x))}
                    sx={{ flex: 2 }} />
                  <TextField label="Sub-sector" value={s.sub_sector} size="small" placeholder="Generics"
                    onChange={e => setSectorRows(r => r.map((x, j) => j===i ? {...x, sub_sector: e.target.value} : x))}
                    sx={{ flex: 2 }} />
                  {sectorRows.length > 1 && (
                    <IconButton size="small" color="error"
                      onClick={() => setSectorRows(r => r.filter((_, j) => j !== i))}>
                      <DeleteIcon fontSize="small" />
                    </IconButton>
                  )}
                </Stack>
              ))}
            </Box>
          </Stack>
        </DialogContent>
        <DialogActions sx={{ p: 2 }}>
          <Button onClick={() => setAddOpen(false)}>Cancel</Button>
          <Button onClick={handleAdd} variant="contained"
            disabled={saving || !newCo.company_id || !newCo.company_name}
            sx={{ bgcolor: '#F97316', '&:hover': { bgcolor: '#EA580C' } }}>
            {saving ? 'Adding…' : 'Add Company'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  )
}
