import React, { useState, useEffect } from 'react'
import Plot from 'react-plotly.js'
import {
  Box, Grid, Card, CardContent, Typography, Stack, Chip, CircularProgress,
  Alert, Paper, Button, ToggleButton, ToggleButtonGroup, Table, TableHead,
  TableRow, TableCell, TableBody, Select, MenuItem, FormControl, InputLabel, Divider,
  Tooltip, IconButton
} from '@mui/material'
import DownloadIcon from '@mui/icons-material/Download'
import { useFilter } from '../../App'
import { fetchDashboard, fetchAltmanDetail, DashboardData, AltmanDetail } from '../../api/client'
import RefreshIcon from '@mui/icons-material/Refresh'
import TrendingUpIcon from '@mui/icons-material/TrendingUp'
import TrendingDownIcon from '@mui/icons-material/TrendingDown'

const CRORE = 10
const COST_ITEMS = [
  'Cost of Materials Consumed', 'Employee Benefit Expenses',
  'Power, Fuel and Electricity', 'Transportation Cost',
  'Finance Costs', 'Depreciation and Amortisation',
  'Other Expenses', 'Consumables', 'Rest in Other Expenses',
]
const CHART_COLORS = ['#1A56DB','#0D9488','#7C3AED','#D97706','#DC2626','#059669','#0891B2','#EA580C','#8B5CF6']

function KPICard({ label, value, sub, unit='INR Mn', color='#0B2545', yoy, div=1 }: any) {
  const fmt = (v: any) => v==null ? '—' : Number(v/div).toLocaleString('en-IN',{maximumFractionDigits:1})
  return (
    <Card sx={{ height:'100%', borderTop:`4px solid ${color}` }}>
      <CardContent sx={{ pb:'12px !important', pt:1.5, px:1.5 }}>
        <Typography variant="caption" color="text.secondary" fontWeight={600} sx={{ letterSpacing:0.5, fontSize:10 }}>
          {String(label).toUpperCase()}
        </Typography>
        <Typography variant="h5" fontWeight={700} color={color} mt={0.3} fontSize={20}>{fmt(value)}</Typography>
        <Stack direction="row" alignItems="center" spacing={0.5} mt={0.3} flexWrap="wrap">
          {unit && <Typography variant="caption" color="text.secondary" fontSize={10}>{unit}</Typography>}
          {sub!=null && <Chip label={typeof sub==='number'?`${sub.toFixed(1)}%`:sub} size="small"
            sx={{ bgcolor:`${color}18`, color, fontWeight:600, height:16, fontSize:9 }} />}
          {yoy!=null && <Chip
            icon={yoy>=0?<TrendingUpIcon sx={{fontSize:'11px !important'}}/>:<TrendingDownIcon sx={{fontSize:'11px !important'}}/>}
            label={`${yoy>=0?'+':''}${Number(yoy).toFixed(1)}% YoY`} size="small"
            sx={{ bgcolor:yoy>=0?'#ECFDF5':'#FEF2F2', color:yoy>=0?'#059669':'#DC2626', fontWeight:600, height:16, fontSize:9 }} />}
        </Stack>
      </CardContent>
    </Card>
  )
}

function ZGauge({ value, zone }: { value?:number; zone?:string }) {
  if (!value) return <Box sx={{height:200,display:'flex',alignItems:'center',justifyContent:'center'}}>
    <Typography color="text.secondary" fontSize={13}>Run analysis to see Z Score</Typography>
  </Box>
  const color = zone==='safe'?'#059669':zone==='grey'?'#D97706':'#DC2626'
  const label = zone==='safe'?'SAFE ZONE':zone==='grey'?'GREY ZONE':'DISTRESS'
  return (
    <Box sx={{ textAlign:'center' }}>
      <Plot data={[{
        type:'indicator', mode:'gauge+number', value,
        number:{ font:{ size:26 }, valueformat:'.2f' },
        gauge:{
          axis:{ range:[0,5], tickwidth:1 }, bar:{ color },
          steps:[{ range:[0,1.81], color:'#FEE2E2' },{ range:[1.81,2.99], color:'#FEF9C3' },{ range:[2.99,5], color:'#DCFCE7' }],
          threshold:{ line:{ color, width:4 }, thickness:0.75, value }
        }
      } as any]}
      layout={{ width:310, height:200, margin:{t:20,b:0,l:30,r:30}, paper_bgcolor:'transparent', font:{family:'Inter,sans-serif',size:11} } as any}
      config={{ displayModeBar: false, responsive: true } as any} />
      <Chip label={label} sx={{ bgcolor:color, color:'#fff', fontWeight:700, mt:-1 }} size="small" />
    </Box>
  )
}

export default function DashboardPage() {
  const { filter } = useFilter()
  const { company: companyId, period, reportType } = filter

  const [data, setData]         = useState<DashboardData|null>(null)
  const [altman, setAltman]     = useState<AltmanDetail|null>(null)
  const [loading, setLoading]   = useState(false)
  const [error, setError]       = useState('')
  const [dispUnit, setDispUnit] = useState<'million'|'crore'>('million')
  const [costChartType, setCostChartType] = useState<'pie'|'bar'>('pie')
  const [costMetric, setCostMetric] = useState<'absolute'|'pct_cost'|'pct_revenue'>('absolute')

  const div = dispUnit === 'crore' ? CRORE : 1
  const unitLabel = dispUnit === 'crore' ? 'INR Cr' : 'INR Mn'

  const load = () => {
    if (!companyId) return
    setLoading(true); setError('')
    Promise.all([
      fetchDashboard(companyId, period, reportType),
      fetchAltmanDetail(companyId, period),
    ]).then(([d, a]) => { setData(d); setAltman(a) })
      .catch(e => setError(e.message))
      .finally(() => setLoading(false))
  }

  useEffect(() => { load() }, [companyId, period, reportType])

  if (!companyId) return (
    <Box sx={{display:'flex',alignItems:'center',justifyContent:'center',height:400}}>
      <Typography color="text.secondary">Select a company in the top bar</Typography>
    </Box>
  )
  if (loading) return <Box sx={{display:'flex',justifyContent:'center',py:10}}><CircularProgress /></Box>

  const kpis  = data?.kpis || {}
  const trend = data?.trend || {}
  const cost  = data?.cost_structure || []

  // Trend series — sorted
  const sortYr = (arr: any[]) => [...arr].sort((a,b)=>a.year.localeCompare(b.year))
  const revData = sortYr(trend['Revenue from Operations']||[])
  const ebdData = sortYr(trend['EBITDA']||[])
  const patData = sortYr(trend['PAT']||[])
  const zData   = sortYr(trend['Altman Z Score']||[])
  const years   = revData.map(d=>d.year)

  // Cost chart data with metric
  const totalCost = cost.reduce((s,c)=>s+c.value,0)
  const revValue  = (kpis.revenue?.value||0)
  const costDisplay = cost.map(c => {
    let y = c.value/div
    if (costMetric === 'pct_cost')    y = totalCost ? c.value/totalCost*100 : 0
    if (costMetric === 'pct_revenue') y = revValue  ? c.value/revValue*100 : 0
    return { ...c, display: y }
  })
  const costSuffix = costMetric==='absolute' ? unitLabel : '%'

  return (
    <Box>
      {/* Header */}
      <Stack direction="row" justifyContent="space-between" alignItems="center" mb={2.5} flexWrap="wrap" gap={1}>
        <Box>
          <Typography variant="h5" fontWeight={700} color="#0B2545">Analytics Dashboard</Typography>
          <Typography variant="body2" color="text.secondary">
            {companyId} · {period} · {reportType === 'consolidated' ? 'Consolidated' : 'Standalone'}
          </Typography>
        </Box>
        <Stack direction="row" spacing={1.5} alignItems="center">
          <ToggleButtonGroup value={dispUnit} exclusive size="small"
            onChange={(_,v)=>v&&setDispUnit(v)}
            sx={{'& .MuiToggleButton-root':{px:1.5,py:0.4,fontSize:12,textTransform:'none'}}}>
            <ToggleButton value="million">₹ Million</ToggleButton>
            <ToggleButton value="crore">₹ Crore</ToggleButton>
          </ToggleButtonGroup>
          <Button startIcon={<RefreshIcon />} onClick={load} variant="outlined" size="small">Refresh</Button>
        </Stack>
      </Stack>

      {error && <Alert severity="error" sx={{mb:2}}>{error}</Alert>}
      {/* No data state — shown when warehouse has no active rows for this period */}
      {!loading && (data?.no_data || (!kpis.revenue?.value && !kpis.total_assets?.value)) && (
        <Alert severity="warning" sx={{mb:2, py:1.5}} icon={<span style={{fontSize:20}}>📭</span>}>
          <strong>No Financial Data</strong>
          {data?.message ? ` — ${data.message}` : ` for ${companyId} · ${period}.`}
          {' '}
          {data?.years && data.years.length > 0
            ? `Available periods: ${(data.years as string[]).slice(0,5).join(', ')}`
            : 'Go to Data Input → enter values → click Analyze.'}
        </Alert>
      )}

      {/* KPI Cards — 4 per row */}
      <Grid container spacing={1.5} mb={2.5}>
        {[
          { label:'Revenue',       value:kpis.revenue?.value,       yoy:kpis.revenue?.yoy,   color:'#1A56DB' },
          { label:'EBITDA',        value:kpis.ebitda?.value,        sub:kpis.ebitda?.margin, color:'#0D9488' },
          { label:'EBIT',          value:kpis.ebit?.value,          sub:kpis.ebit?.margin,   color:'#7C3AED' },
          { label:'PAT',           value:kpis.pat?.value,           sub:kpis.pat?.margin,    color:'#059669' },
          { label:'Total Assets',  value:kpis.total_assets?.value,  yoy:kpis.total_assets?.yoy, color:'#0B2545' },
          { label:'Net Worth',     value:kpis.net_worth?.value,                              color:'#0891B2' },
          { label:'Working Capital',value:kpis.working_capital?.value,                       color:'#D97706' },
          { label:'Current Ratio', value:kpis.current_ratio?.value,  unit:'Ratio',           color:'#EA580C', div:1 },
          { label:'ROE',           value:kpis.roe?.value,            unit:'%',               color:'#8B5CF6', div:1 },
        ].map(card => (
          <Grid item xs={6} sm={4} md={3} lg={2} key={card.label}>
            <KPICard {...card} unit={card.unit||unitLabel} div={card.div??div} />
          </Grid>
        ))}
        {/* Altman Z gauge */}
        <Grid item xs={6} sm={4} md={3} lg={3}>
          <Card sx={{ height:'100%', borderTop:'4px solid #DC2626' }}>
            <ZGauge value={kpis.altman_z?.value??undefined} zone={kpis.altman_z?.zone} />
          </Card>
        </Grid>
      </Grid>

      {/* Revenue + EBITDA trend */}
      <Grid container spacing={2} mb={2}>
        <Grid item xs={12} md={8}>
          <Paper sx={{ p:2 }}>
            <Typography variant="subtitle1" fontWeight={700} mb={1}>Revenue & EBITDA Trend ({unitLabel})</Typography>
            {revData.length>0 ? (
              <Plot
                data={[
                  { x:years, y:revData.map(d=>d.value/div), type:'bar', name:'Revenue', marker:{color:'#1A56DB'} } as any,
                  { x:years, y:ebdData.map(d=>d.value/div), type:'scatter', mode:'lines+markers',
                    name:'EBITDA', line:{color:'#0D9488',width:3}, yaxis:'y2' } as any,
                ]}
                layout={{ height:260, margin:{t:10,b:40,l:70,r:60}, paper_bgcolor:'transparent', plot_bgcolor:'transparent',
                  yaxis:{gridcolor:'#E2E8F0', title:unitLabel}, yaxis2:{overlaying:'y',side:'right',showgrid:false},
                  legend:{x:0,y:1.12,orientation:'h'}, font:{family:'Inter,sans-serif',size:12} } as any}
                style={{width:'100%'}} config={{ displayModeBar: false, responsive: true } as any}
              />
            ) : <Box sx={{height:260,display:'flex',alignItems:'center',justifyContent:'center'}}><Typography color="text.secondary">Run analysis to see trends</Typography></Box>}
          </Paper>
        </Grid>

        {/* Cost Structure — vertical grouped bar, full labels, metric selector */}
        <Grid item xs={12} md={4}>
          <Paper sx={{ p:2 }}>
            <Stack direction="row" justifyContent="space-between" alignItems="center" mb={1} flexWrap="wrap" gap={0.5}>
              <Typography variant="subtitle1" fontWeight={700}>Cost Structure</Typography>
              <Stack direction="row" spacing={0.5} alignItems="center">
                <FormControl size="small" sx={{minWidth:130}}>
                  <Select value={costMetric} onChange={e=>setCostMetric(e.target.value as any)}
                    sx={{fontSize:11,'& .MuiSelect-select':{py:0.4}}}>
                    <MenuItem value="absolute" sx={{fontSize:12}}>Absolute ({unitLabel})</MenuItem>
                    <MenuItem value="pct_cost" sx={{fontSize:12}}>% Total Cost</MenuItem>
                    <MenuItem value="pct_revenue" sx={{fontSize:12}}>% Revenue</MenuItem>
                  </Select>
                </FormControl>
                <Tooltip title="Download chart as PNG">
                  <IconButton size="small" onClick={() => {
                    const el = document.getElementById('dashboard-cost-chart')
                    if (el && (window as any).Plotly) {
                      ;(window as any).Plotly.toImage(el, { format:'png', scale:3, width:900, height:420 })
                        .then((url: string) => {
                          const a = document.createElement('a')
                          a.href = url
                          a.download = `cost_structure_${companyId}_${period}.png`
                          a.click()
                        })
                    }
                  }}>
                    <DownloadIcon sx={{ fontSize: 16 }} />
                  </IconButton>
                </Tooltip>
              </Stack>
            </Stack>
            {cost.length>0 ? (
              <Plot
                divId="dashboard-cost-chart"
                // Single stacked vertical bar — one bar total, each segment = one cost item
                data={
                  [...costDisplay]
                    .sort((a,b) => b.display - a.display)
                    .map((c, i) => ({
                      type: 'bar',
                      name: c.item,
                      x: ['Cost Structure'],   // single X category
                      y: [c.display],
                      marker: { color: CHART_COLORS[i % CHART_COLORS.length], opacity: 0.88 },
                      hovertemplate:
                        `<b>${c.item}</b><br>` +
                        (costMetric==='absolute'
                          ? `${(c.display/div).toLocaleString('en-IN',{maximumFractionDigits:0})} ${unitLabel}`
                          : `${c.display.toFixed(1)}%`) +
                        (costMetric!=='pct_cost'
                          ? `<br>${totalCost?(c.value/totalCost*100).toFixed(1)+'% of total':''}` : '') +
                        '<extra></extra>',
                      text: c.display > (costMetric==='absolute' ? totalCost*0.05 : 5)
                        ? (costMetric==='absolute'
                            ? (c.display/div/1000).toFixed(0)+'K'
                            : c.display.toFixed(0)+'%')
                        : '',
                      textposition: 'inside',
                      insidetextanchor: 'middle',
                      textfont: { size: 10, color: 'white' },
                    } as any))
                }
                layout={{
                  height: 340,
                  margin: { t: 20, b: 30, l: 70, r: 10 },
                  paper_bgcolor: 'transparent',
                  plot_bgcolor: 'transparent',
                  barmode: 'stack',
                  yaxis: {
                    title: costMetric==='absolute' ? unitLabel : '%',
                    gridcolor: '#E2E8F0',
                    tickformat: costMetric==='absolute' ? ',.0f' : '.1f',
                    zeroline: false,
                  },
                  xaxis: { tickfont: { size: 12, color: "#0B2545", family: "Inter, sans-serif" }, showticklabels: false },
                  legend: {
                    orientation: 'v',
                    x: 1.02, y: 1,
                    font: { size: 9 },
                    traceorder: 'normal',
                  },
                  annotations: [{
                    xref: 'paper', yref: 'paper',
                    x: -0.12, y: -0.06,
                    text: `Total: ${costMetric==='absolute'
                      ? (totalCost/div/1000).toFixed(0)+'K '+unitLabel
                      : '100%'}`,
                    showarrow: false,
                    font: { size: 11, color: '#64748B' },
                  }],
                  hoverlabel: { bgcolor: 'white', bordercolor: '#E2E8F0', font: { size: 11 } },
                  font: { family: 'Inter,sans-serif', size: 11 },
                } as any}
                style={{ width: '100%' }}
                config={{ displayModeBar: false, responsive: true } as any}
              />
            ) : <Box sx={{height:320,display:'flex',alignItems:'center',justifyContent:'center'}}><Typography color="text.secondary">No cost data</Typography></Box>}
          </Paper>
        </Grid>
      </Grid>

      {/* PAT trend + Altman Z trend */}
      <Grid container spacing={2} mb={2}>
        {patData.length>0 && (
          <Grid item xs={12} md={6}>
            <Paper sx={{ p:2 }}>
              <Typography variant="subtitle1" fontWeight={700} mb={1}>PAT Trend ({unitLabel})</Typography>
              <Plot
                data={[{ x:patData.map(d=>d.year), y:patData.map(d=>d.value/div), type:'scatter',
                  mode:'lines+markers', name:'PAT', line:{color:'#7C3AED',width:3}, marker:{size:8} } as any]}
                layout={{ height:200, margin:{t:5,b:40,l:70,r:20}, paper_bgcolor:'transparent', plot_bgcolor:'transparent',
                  yaxis:{gridcolor:'#E2E8F0'}, font:{family:'Inter,sans-serif',size:12} } as any}
                style={{width:'100%'}} config={{ displayModeBar: false, responsive: true } as any}
              />
            </Paper>
          </Grid>
        )}
        {zData.length>0 && (
          <Grid item xs={12} md={6}>
            <Paper sx={{ p:2 }}>
              <Typography variant="subtitle1" fontWeight={700} mb={1}>Altman Z Score Trend</Typography>
              <Plot
                data={[{
                  // Vertical bar chart — each bar colored by zone (green/yellow/red)
                  type: 'bar',
                  x: zData.map(d => d.year),
                  y: zData.map(d => d.value),
                  marker: {
                    color: zData.map(d =>
                      d.value > 2.99 ? '#059669' :   // Safe — green
                      d.value > 1.81 ? '#D97706' :   // Grey zone — amber
                      '#DC2626'                       // Distress — red
                    ),
                    opacity: 0.85,
                  },
                  text: zData.map(d => d.value.toFixed(2)),
                  textposition: 'outside',
                  textfont: { size: 11, color: '#1E293B' },
                  hovertemplate:
                    '<b>%{x}</b><br>' +
                    'Z Score: <b>%{y:.2f}</b><br>' +
                    '%{customdata}<extra></extra>',
                  customdata: zData.map(d =>
                    d.value > 2.99 ? '✅ Safe Zone (Z > 2.99)' :
                    d.value > 1.81 ? '🟡 Grey Zone (1.81–2.99)' :
                    '🔴 Distress Zone (Z < 1.81)'
                  ),
                  showlegend: false,
                } as any,
                // Safe threshold line
                { x: zData.map(d=>d.year), y: Array(zData.length).fill(2.99),
                  type:'scatter', mode:'lines', name:'Safe (2.99)',
                  line:{ color:'#059669', dash:'dot', width:1.5 } } as any,
                // Distress threshold line
                { x: zData.map(d=>d.year), y: Array(zData.length).fill(1.81),
                  type:'scatter', mode:'lines', name:'Distress (1.81)',
                  line:{ color:'#DC2626', dash:'dot', width:1.5 } } as any,
                ]}
                layout={{
                  height: 240,
                  margin: { t: 30, b: 40, l: 50, r: 20 },
                  paper_bgcolor: 'transparent', plot_bgcolor: 'transparent',
                  yaxis: { gridcolor:'#E2E8F0', range:[0, Math.max(...zData.map(d=>d.value))*1.25||6], title:'Z Score' },
                  xaxis: { tickfont:{ size:11, color: "#0B2545", family: "Inter, sans-serif" } },
                  legend: { x:0, y:1.15, orientation:'h', font:{size:10} },
                  shapes: [
                    // Green band above 2.99
                    { type:'rect', xref:'paper', x0:0, x1:1, y0:2.99, y1:Math.max(...zData.map(d=>d.value))*1.25||6,
                      fillcolor:'rgba(5,150,105,0.05)', line:{width:0} },
                    // Amber band 1.81–2.99
                    { type:'rect', xref:'paper', x0:0, x1:1, y0:1.81, y1:2.99,
                      fillcolor:'rgba(217,119,6,0.05)', line:{width:0} },
                    // Red band below 1.81
                    { type:'rect', xref:'paper', x0:0, x1:1, y0:0, y1:1.81,
                      fillcolor:'rgba(220,38,38,0.05)', line:{width:0} },
                  ],
                  hoverlabel: { bgcolor:'white', bordercolor:'#E2E8F0', font:{size:11} },
                  font: { family:'Inter,sans-serif', size:12 },
                } as any}
                style={{width:'100%'}}
                config={{ displayModeBar: false, responsive: true } as any}
              />
            </Paper>
          </Grid>
        )}
      </Grid>

      {/* Altman Z Decomposition Table */}
      {altman?.components && (
        <Paper sx={{ p:2 }}>
          <Stack direction="row" spacing={1.5} alignItems="center" mb={1.5}>
            <Typography variant="subtitle1" fontWeight={700}>
              Altman Z Decomposition — {altman.year}
            </Typography>
            {altman.z_score!=null && (
              <Chip label={`Z = ${Number(altman.z_score).toFixed(2)}`}
                sx={{ bgcolor: altman.zone==='safe'?'#059669':altman.zone==='grey'?'#D97706':'#DC2626',
                  color:'#fff', fontWeight:700 }} size="small" />
            )}
          </Stack>
          <Table size="small">
            <TableHead>
              <TableRow sx={{'& th':{fontWeight:700, bgcolor:'#F1F5F9', fontSize:12}}}>
                <TableCell>Component</TableCell>
                <TableCell>Formula</TableCell>
                <TableCell align="right">Weight</TableCell>
                <TableCell align="right">Raw Value</TableCell>
                <TableCell align="right">Contribution</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {Object.entries(altman.components).map(([key, comp]: [string, any]) => {
                const contrib = comp.value!=null ? comp.weight * comp.value : null
                return (
                  <TableRow key={key} sx={{'&:hover':{bgcolor:'#F8FAFC'}}}>
                    <TableCell><Typography fontWeight={700} fontSize={13} color="#0B2545">{key}</Typography></TableCell>
                    <TableCell><Typography fontSize={12} color="text.secondary">{comp.name}</Typography></TableCell>
                    <TableCell align="right"><Typography fontSize={13}>{comp.weight}×</Typography></TableCell>
                    <TableCell align="right">
                      <Typography fontSize={13} fontWeight={500}>
                        {comp.value!=null ? Number(comp.value).toFixed(4) : '—'}
                      </Typography>
                    </TableCell>
                    <TableCell align="right">
                      <Chip label={contrib!=null ? Number(contrib).toFixed(3) : '—'}
                        size="small"
                        sx={{ bgcolor:contrib&&contrib>0?'#ECFDF5':contrib&&contrib<0?'#FEF2F2':'#F1F5F9',
                          color:contrib&&contrib>0?'#059669':contrib&&contrib<0?'#DC2626':'#64748B',
                          fontWeight:600, fontSize:11 }} />
                    </TableCell>
                  </TableRow>
                )
              })}
              <TableRow sx={{ bgcolor:'#F1F5F9' }}>
                <TableCell colSpan={4}><Typography fontWeight={700} fontSize={13}>Total Z Score</Typography></TableCell>
                <TableCell align="right">
                  <Typography fontWeight={700} fontSize={14}
                    sx={{ color: altman.zone==='safe'?'#059669':altman.zone==='grey'?'#D97706':'#DC2626' }}>
                    {altman.z_score!=null ? Number(altman.z_score).toFixed(2) : '—'}
                  </Typography>
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
          <Stack direction="row" spacing={1} mt={1.5}>
            {[['Safe Zone: Z > 2.99','#059669'],['Grey Zone: 1.81–2.99','#D97706'],['Distress: Z < 1.81','#DC2626']].map(([l,c])=>(
              <Box key={l} sx={{px:1.5,py:0.5,bgcolor:`${c}18`,borderRadius:1,border:`1px solid ${c}40`}}>
                <Typography fontSize={11} fontWeight={600} sx={{color:c}}>{l}</Typography>
              </Box>
            ))}
          </Stack>
        </Paper>
      )}
    </Box>
  )
}
