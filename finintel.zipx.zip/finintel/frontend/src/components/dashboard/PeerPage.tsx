import React, { useState, useEffect, useCallback, useRef } from 'react'
import Plot from 'react-plotly.js'
// Plotly loaded from CDN (see index.html) — available as window.Plotly
import {
  Box, Typography, Stack, Paper, Grid, FormControl, InputLabel, Select,
  MenuItem, CircularProgress, Table, TableBody, TableCell, TableHead,
  TableRow, Chip, Button, Checkbox, ListItemText, OutlinedInput,
  ToggleButton, ToggleButtonGroup, Alert, Tooltip, Snackbar
} from '@mui/material'
import { useFilter } from '../../App'
import {
  fetchSectors, fetchCompaniesInSector, fetchCompanies,
  fetchPeerCostStructure, fetchPeerMultiMetric, fetchSectorRanking, fetchPeerTrend,
} from '../../api/client'
import CompareArrowsIcon from '@mui/icons-material/CompareArrows'
import DownloadIcon      from '@mui/icons-material/Download'
import SlideshowIcon     from '@mui/icons-material/Slideshow'
import ImageIcon         from '@mui/icons-material/Image'

// ─── Constants ─────────────────────────────────────────────────────
const COST_SEGMENTS = [
  "Raw Material Cost","Consumables","Power & Fuel",
  "Transportation","Manpower","Rest in Other Expenses",
  "Finance Costs","Depreciation & Amortization",
  "Remaining Expenses","Operational PBT",
]
const COST_COLORS = [
  "#1A56DB","#0D9488","#7C3AED","#D97706",
  "#DC2626","#059669","#0891B2","#EA580C","#8B5CF6","#64748B",
]
const COMPANY_COLORS = [
  "#1A56DB","#0D9488","#7C3AED","#D97706",
  "#DC2626","#059669","#0891B2","#EA580C",
]
const PEER_METRICS = [
  { label:"Revenue",          value:"Revenue from Operations" },
  { label:"Revenue Growth %", value:"Revenue Growth" },
  { label:"EBITDA",           value:"EBITDA" },
  { label:"EBITDA Margin %",  value:"EBITDA Margin" },
  { label:"EBIT",             value:"EBIT" },
  { label:"PAT",              value:"PAT" },
  { label:"PAT Margin %",     value:"PAT Margin" },
  { label:"Total Assets",     value:"Total Assets" },
  { label:"Net Worth",        value:"Net Worth" },
  { label:"Current Ratio",    value:"Current Ratio" },
  { label:"Working Capital",  value:"Working Capital" },
  { label:"ROE %",            value:"ROE" },
  { label:"Finance Costs",    value:"Finance Costs" },
  { label:"Altman Z Score",   value:"Altman Z Score" },
]

const TREND_METRICS = [
  { label: "Revenue",           value: "Revenue from Operations" },
  { label: "Revenue Growth %",  value: "Revenue Growth" },
  { label: "EBITDA",            value: "EBITDA" },
  { label: "EBITDA Margin %",   value: "EBITDA Margin" },
  { label: "EBIT",              value: "EBIT" },
  { label: "PAT",               value: "PAT" },
  { label: "PAT Margin %",      value: "PAT Margin" },
  { label: "Current Ratio",     value: "Current Ratio" },
  { label: "ROE %",             value: "ROE" },
  { label: "Working Capital",   value: "Working Capital" },
  { label: "Finance Costs",     value: "Finance Costs" },
  { label: "Altman Z Score",    value: "Altman Z Score" },
  { label: "Total Assets",      value: "Total Assets" },
  { label: "Total Equity",      value: "Total Equity" },
]
const ALL_FY = ["FY19","FY20","FY21","FY22","FY23","FY24","FY25","FY26"]

type CostMode = 'absolute' | 'pct_revenue' | 'pct_total_cost'
const fmt = (v: any) =>
  v == null ? '—' : Number(v).toLocaleString('en-IN', { maximumFractionDigits: 1 })

// ─── Component ─────────────────────────────────────────────────────
export default function PeerPage() {
  const { filter }  = useFilter()
  const period      = filter.period
  const reportType  = filter.reportType

  const [sectors, setSectors]             = useState<string[]>([])
  const [sector, setSector]               = useState('')
  const [availCos, setAvailCos]           = useState<any[]>([])
  const [selectedCos, setSelectedCos]     = useState<string[]>([])
  const [selectedMetrics, setSelectedMetrics] = useState<string[]>([
    'Revenue from Operations','EBITDA','PAT',
  ])
  const [costMode, setCostMode]           = useState<CostMode>('absolute')
  const [costData, setCostData]           = useState<any>(null)
  const [metricData, setMetricData]       = useState<any>(null)
  const [ranking, setRanking]             = useState<any[]>([])
  const [costLoading, setCostLoading]     = useState(false)
  const [metricLoading, setMetricLoading] = useState(false)
  const [exporting, setExporting]         = useState<'cost-png'|'metric-png'|'metric-ppt'|null>(null)
  const [toast, setToast]                 = useState('')
  // Click interaction: highlighted segment per company
  const [clickedSeg, setClickedSeg]       = useState<string|null>(null)
  const costPlotRef   = useRef<any>(null)
  const metricPlotRef = useRef<any>(null)

  // ── Trend state ────────────────────────────────────────────────
  const [trendMetric,    setTrendMetric]    = useState('Revenue from Operations')
  const [trendStartYear, setTrendStartYear] = useState('FY20')
  const [trendEndYear,   setTrendEndYear]   = useState('FY25')
  const [trendViewMode,  setTrendViewMode]  = useState<'line'|'bar'>('line')
  const [trendData,      setTrendData]      = useState<any>(null)
  const [trendLoading,   setTrendLoading]   = useState(false)

  // ── Load sectors ────────────────────────────────────────────────
  useEffect(() => {
    fetchSectors().then((s: string[]) => {
      const all = ['All Sectors', ...s]; setSectors(all); setSector(all[0])
    }).catch(() => {})
  }, [])

  // ── Load companies ──────────────────────────────────────────────
  useEffect(() => {
    if (!sector) return
    const p = sector === 'All Sectors' ? fetchCompanies() : fetchCompaniesInSector(sector)
    p.then((cos: any[]) => {
      setAvailCos(cos); setSelectedCos(cos.map((c: any) => c.company_id))
    }).catch(() => {})
  }, [sector])

  // ── Fetch all data ──────────────────────────────────────────────
  const fetchAll = useCallback(() => {
    if (!selectedCos.length) return
    setCostLoading(true)
    fetchPeerCostStructure({ companies: selectedCos, period, report_type: reportType, unit: 'absolute' })
      .then(setCostData).catch(() => setCostData(null)).finally(() => setCostLoading(false))
    setMetricLoading(true)
    Promise.all([
      fetchPeerMultiMetric({ companies: selectedCos, metrics: selectedMetrics, period, report_type: reportType }),
      fetchSectorRanking(sector === 'All Sectors' ? 'ALL' : sector, period).catch(() => []),
    ]).then(([md, rank]) => { setMetricData(md); setRanking(rank) })
      .catch(() => setMetricData(null)).finally(() => setMetricLoading(false))
  }, [selectedCos, selectedMetrics, period, reportType, sector])

  useEffect(() => {
    if (selectedCos.length && (costData || metricData)) fetchAll()
  }, [period, reportType])

  const fetchTrend = useCallback(() => {
    if (!selectedCos.length) return
    setTrendLoading(true)
    fetchPeerTrend({
      companies: selectedCos, metric: trendMetric,
      start_year: trendStartYear, end_year: trendEndYear,
      report_type: reportType,
    }).then(setTrendData).catch(() => setTrendData(null)).finally(() => setTrendLoading(false))
  }, [selectedCos, trendMetric, trendStartYear, trendEndYear, reportType])

  // ── Computed display value per segment per company ──────────────
  const cosWithData = costData ? selectedCos.filter(c => costData.data?.[c]) : []

  function segDisplayValue(co: string, seg: string): number | null {
    const d = costData?.data?.[co]
    if (!d) return null
    const raw = d[seg] ?? 0
    if (!raw) return null
    if (costMode === 'pct_revenue') {
      const rv = d['_revenue'] || 1
      return parseFloat((raw / rv * 100).toFixed(2))
    }
    if (costMode === 'pct_total_cost') {
      // If no valid total cost (company lacks cost breakdown), fall back to revenue
      const tc = (d['_total_cost'] && d['_total_cost'] > 0) ? d['_total_cost'] : d['_revenue'] || 1
      return parseFloat((raw / tc * 100).toFixed(2))
    }
    return raw
  }

  // Segments sorted descending by average value across companies (largest at bottom)
  // Sort by ABSOLUTE average across companies (consistent ordering in all 3 display modes)
  // Ascending = largest at bottom of stack (Plotly stacks from bottom up)
  const sortedSegments = [...COST_SEGMENTS].sort((a, b) => {
    const rawA = cosWithData.reduce((s, co) => {
      const d = costData?.data?.[co]; return s + ((d?.[a] ?? 0) as number)
    }, 0) / Math.max(cosWithData.length, 1)
    const rawB = cosWithData.reduce((s, co) => {
      const d = costData?.data?.[co]; return s + ((d?.[b] ?? 0) as number)
    }, 0) / Math.max(cosWithData.length, 1)
    return rawA - rawB   // ascending → largest at bottom of each stacked bar
  })

  // ── Build cost traces ─────────────────────────────────────────────
  // Pre-compute per-company segment ranks (sorted descending by raw absolute value)
  const segRanks: Record<string, Record<string, number>> = {}
  cosWithData.forEach(co => {
    const segsWithVals = COST_SEGMENTS
      .map(s => ({ s, v: costData?.data?.[co]?.[s] ?? 0 }))
      .sort((a, b) => b.v - a.v)
    segsWithVals.forEach(({ s }, i) => {
      if (!segRanks[co]) segRanks[co] = {}
      segRanks[co][s] = i + 1
    })
  })

  const costTraces = sortedSegments.map((seg) => {
    const segIdx = COST_SEGMENTS.indexOf(seg)
    const color  = COST_COLORS[segIdx % COST_COLORS.length]
    const isHi   = clickedSeg === null || clickedSeg === seg

    return {
      type: 'bar' as const,
      name: seg,
      x: cosWithData,
      y: cosWithData.map(co => segDisplayValue(co, seg)),
      marker: {
        color,
        opacity: isHi ? 0.92 : 0.25,
        line: clickedSeg === seg
          ? { color: '#F97316', width: 2.5 }
          : { color: 'rgba(0,0,0,0)', width: 0 },
      },
      // Per-trace tooltip border = segment color, giving a visual color indicator
      hoverlabel: {
        bgcolor:     '#1E293B',
        bordercolor: color,
        font: { size: 13, color: '#F8FAFC', family: 'Inter, sans-serif' },
        align: 'left' as const,
      },
      // customdata: [company, raw_mn, pct_rev, pct_tc, rank, seg_name]
      customdata: cosWithData.map(co => {
        const d   = costData?.data?.[co]
        const raw = d?.[seg] ?? 0
        const rv  = d?.['_revenue']    || 1
        const tc  = d?.['_total_cost'] || 1
        const rk  = segRanks[co]?.[seg] ?? '—'
        return [co, raw, (raw / rv * 100).toFixed(2), (raw / tc * 100).toFixed(2), rk, seg]
      }),
      // Tooltip: Plotly strips inline style= attributes, so we cannot colour
      // individual words. Instead we use the legendgroup color as the trace's
      // hoverlabel.bordercolor (set globally below in the layout) and rely on
      // bold / structured layout for legibility.
      // customdata: [company, raw_mn, pct_rev, pct_tc, rank, seg_name]
      hovertemplate: (
        '<b>%{customdata[0]}</b><br>' +
        '<b>■ %{customdata[5]}</b><br>' +
        '<b>₹ %{customdata[1]:,.0f} Mn</b><br>' +
        '%{customdata[2]}% of Revenue<br>' +
        '%{customdata[3]}% of Total Cost<br>' +
        'Rank #%{customdata[4]} of ' + COST_SEGMENTS.length +
        '<extra></extra>'
      ),
      // Label visibility: show inside for large segments (≥ 9% of stack), hide for small ones.
      // Small segments are always readable via hover tooltip.
      text: cosWithData.map(co => {
        const v = segDisplayValue(co, seg)
        if (!v || v <= 0) return ''
        // Compute this segment's share of the full visible stack
        const stackTotal = sortedSegments.reduce(
          (s, s2) => s + (segDisplayValue(co, s2) ?? 0), 0
        ) || 1
        const pctOfStack = v / stackTotal * 100
        if (pctOfStack < 9) return ''    // too small — tooltip handles it
        if (costMode === 'absolute') {
          return v >= 100000 ? `${(v/1000).toFixed(0)}K` : `${(v/1000).toFixed(1)}K`
        }
        return `${v.toFixed(1)}%`
      }),
      textposition: 'inside' as const,
      insidetextanchor: 'middle' as const,
      textfont:      { size: 9, color: 'white', family: 'Inter, sans-serif' },
      outsidetextfont: { size: 9, color: '#334155', family: 'Inter, sans-serif' },
      cliponaxis:    false,
    }
  })

  // ── Trend traces ─────────────────────────────────────────────────
  const trendYears  = trendData?.years ?? []
  const trendLabel  = TREND_METRICS.find(m => m.value === trendMetric)?.label ?? trendMetric
  const trendTraces = (trendData?.series ?? []).map((s: any, ci: number) => ({
    type:    trendViewMode === 'line' ? 'scatter' as const : 'bar' as const,
    mode:    trendViewMode === 'line' ? 'lines+markers' as const : undefined,
    name:    s.company_id,
    x:       trendYears,
    y:       s.values,
    marker:  { color: COMPANY_COLORS[ci % COMPANY_COLORS.length], size: 8 },
    line:    trendViewMode === 'line' ? { color: COMPANY_COLORS[ci % COMPANY_COLORS.length], width: 2.5 } : undefined,
    hovertemplate: `<b>${s.company_id}</b><br>${trendLabel}: <b>%{y:,.1f}</b><br>%{x}<extra></extra>`,
  }))

  // Totals annotation at top of each stack
  const costAnnotations = cosWithData.map(co => {
    const total = sortedSegments.reduce((s, seg) => s + (segDisplayValue(co, seg) ?? 0), 0)
    if (!total) return null
    const label = costMode === 'absolute'
      ? `${(total / 1000).toFixed(0)}K`
      : `${total.toFixed(0)}%`
    return {
      x: co, y: total,
      text: `<b>${label}</b>`,
      showarrow: false, yanchor: 'bottom' as const,
      font: { size: 11, color: '#0B2545', family: 'Inter, sans-serif' },
      bgcolor: 'rgba(255,255,255,0.85)', borderpad: 3,
    }
  }).filter(Boolean)

  const yAxisTitle = costMode === 'absolute' ? 'INR Mn'
    : costMode === 'pct_revenue'    ? '% of Revenue'
    : '% of Total Cost'
  const yTickFmt = costMode === 'absolute' ? ',.0f' : '.1f'

  // ── Click handler ───────────────────────────────────────────────
  const onCostClick = useCallback((e: any) => {
    const seg = e?.points?.[0]?.data?.name
    setClickedSeg(prev => (prev === seg ? null : (seg ?? null)))
  }, [])

  // ── Multi-metric traces ─────────────────────────────────────────
  const metricLabels  = selectedMetrics.map(m => PEER_METRICS.find(x => x.value === m)?.label || m)
  const metricTraces  = selectedCos.map((co, ci) => ({
    type: 'bar' as const,
    name: co,
    x: metricLabels,
    y: selectedMetrics.map(m => metricData?.table?.[m]?.[co] ?? null),
    marker: { color: COMPANY_COLORS[ci % COMPANY_COLORS.length] },
    hovertemplate:
      `<b>${co}</b><br>%{x}: <b style="color:#ff8c00">%{y:,.1f}</b><extra></extra>`,
  }))

  // ── Export helpers ──────────────────────────────────────────────
  const downloadBlob = (buf: ArrayBuffer, filename: string, mime: string) => {
    const blob = new Blob([buf], { type: mime })
    const url  = URL.createObjectURL(blob)
    const a    = document.createElement('a'); a.href = url; a.download = filename; a.click()
    URL.revokeObjectURL(url)
  }

  // Cost structure PNG — use Plotly.toImage on the plot's own DOM node via ref
  const exportCostPNG = async () => {
    setExporting('cost-png')
    // When Plotly is loaded from CDN, use divId to locate the plot element
    // and call window.Plotly.toImage directly — this is the most reliable approach.
    try {
      const plotEl = document.getElementById('cost-structure-plot')
      if (plotEl && (window as any).Plotly) {
        const dataUrl: string = await (window as any).Plotly.toImage(plotEl, {
          format: 'png', scale: 3,
          width: Math.max(1200, cosWithData.length * 160 + 260), height: 580,
        })
        const a = document.createElement('a')
        a.href = dataUrl
        a.download = `cost_structure_comparison_${period}.png`
        document.body.appendChild(a); a.click(); document.body.removeChild(a)
        setToast('✓ Cost structure PNG downloaded')
        setExporting(null); return
      }
    } catch (_) {}
    // Fallback: server-side (matplotlib — no Chrome required)
    try {
      const { api } = await import('../../api/client')
      const res = await api.post('/peer/export/png', {
        companies: selectedCos, metrics: selectedMetrics,
        period, report_type: reportType, cost_unit: costMode,
      }, { responseType: 'arraybuffer', timeout: 90000 })
      downloadBlob(res.data, `cost_structure_comparison_${period}.png`, 'image/png')
      setToast('✓ Cost structure PNG downloaded')
    } catch (e2: any) {
      setToast(`PNG export failed: ${e2?.message || 'check server logs'}`)
    } finally { setExporting(null) }
  }

  // Multi-metric PNG
  const exportMetricPNG = async () => {
    setExporting('metric-png')
    try {
      const plotEl = document.getElementById('multi-metric-plot')
      if (plotEl && (window as any).Plotly) {
        const dataUrl: string = await (window as any).Plotly.toImage(plotEl, {
          format: 'png', scale: 3, width: 1200, height: 520,
        })
        const a = document.createElement('a')
        a.href = dataUrl
        a.download = `peer_kpi_comparison_${period}.png`
        document.body.appendChild(a); a.click(); document.body.removeChild(a)
        setToast('✓ Multi-metric PNG downloaded')
        setExporting(null); return
      }
    } catch (_) {}
    // Fallback: server-side matplotlib chart
    try {
      const { api } = await import('../../api/client')
      const res = await api.post('/peer/export/png', {
        companies: selectedCos, metrics: selectedMetrics,
        period, report_type: reportType, cost_unit: costMode,
      }, { responseType: 'arraybuffer', timeout: 90000 })
      downloadBlob(res.data, `peer_kpi_comparison_${period}.png`, 'image/png')
      setToast('✓ Multi-metric PNG downloaded')
    } catch (e2: any) {
      setToast(`PNG export failed: ${e2?.message || 'server error'}`)
    } finally { setExporting(null) }
  }

  // Multi-metric PPT — server-side
  const exportMetricPPT = async () => {
    setExporting('metric-ppt')
    try {
      const { api } = await import('../../api/client')
      const res = await api.post('/peer/export/ppt', {
        companies: selectedCos, metrics: selectedMetrics,
        period, report_type: reportType, cost_unit: costMode, format: 'ppt',
      }, { responseType: 'arraybuffer', timeout: 120000 })
      downloadBlob(
        res.data,
        `peer_kpi_comparison_${period}.pptx`,
        'application/vnd.openxmlformats-officedocument.presentationml.presentation',
      )
      setToast('PowerPoint downloaded')
    } catch (e: any) { setToast(`PPT export failed: ${e?.message}`) }
    finally { setExporting(null) }
  }

  const hasData = cosWithData.length > 0 || (metricData?.data?.length > 0)

  // ── Render ──────────────────────────────────────────────────────
  return (
    <Box>
      <Typography variant="h5" fontWeight={700} color="#0B2545" mb={0.5}>
        Peer Comparison
      </Typography>
      <Typography variant="body2" color="text.secondary" mb={2}>
        {period} · {reportType === 'consolidated' ? 'Consolidated' : 'Standalone'} ·
        Multi-company benchmarking
      </Typography>

      {/* ── Filters ── */}
      <Paper sx={{ p: 2, mb: 2.5 }}>
        <Grid container spacing={2} alignItems="flex-end">
          <Grid item xs={12} sm={3}>
            <FormControl fullWidth size="small">
              <InputLabel>Sector</InputLabel>
              <Select value={sector} label="Sector" onChange={e => setSector(e.target.value)}>
                {sectors.map(s => (
                  <MenuItem key={s} value={s}
                    sx={s === 'All Sectors' ? { fontWeight: 700, borderBottom: '1px solid #E2E8F0' } : {}}>
                    {s}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={4}>
            <FormControl fullWidth size="small">
              <InputLabel>Companies</InputLabel>
              <Select multiple value={selectedCos}
                onChange={e => setSelectedCos(typeof e.target.value === 'string' ? e.target.value.split(',') : e.target.value as string[])}
                input={<OutlinedInput label="Companies" />}
                renderValue={(sel: string[]) => sel.join(', ')}
                MenuProps={{ PaperProps: { style: { maxHeight: 280 } } }}>
                {availCos.map((c: any) => (
                  <MenuItem key={c.company_id} value={c.company_id}>
                    <Checkbox checked={selectedCos.includes(c.company_id)} size="small" />
                    <ListItemText primary={c.company_id} secondary={c.company_name} />
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={4}>
            <FormControl fullWidth size="small">
              <InputLabel>KPI Metrics</InputLabel>
              <Select multiple value={selectedMetrics}
                onChange={e => setSelectedMetrics(typeof e.target.value === 'string' ? e.target.value.split(',') : e.target.value as string[])}
                input={<OutlinedInput label="KPI Metrics" />}
                renderValue={(sel: string[]) => `${sel.length} metric${sel.length !== 1 ? 's' : ''} selected`}
                MenuProps={{ PaperProps: { style: { maxHeight: 320 } } }}>
                {PEER_METRICS.map(m => (
                  <MenuItem key={m.value} value={m.value}>
                    <Checkbox checked={selectedMetrics.includes(m.value)} size="small" />
                    <ListItemText primary={m.label} />
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={1}>
            <Button variant="contained" fullWidth
              onClick={() => { setCostData(null); setMetricData(null); setClickedSeg(null); fetchAll() }}
              disabled={costLoading || metricLoading || !selectedCos.length}
              startIcon={costLoading || metricLoading
                ? <CircularProgress size={14} color="inherit" /> : <CompareArrowsIcon />}
              sx={{ bgcolor: '#0D9488', '&:hover': { bgcolor: '#0F766E' }, height: 40 }}>
              Go
            </Button>
          </Grid>
        </Grid>
      </Paper>

      {!hasData && !costLoading && !metricLoading && (
        <Alert severity="info">
          Select sector and companies above, then click <strong>Go</strong> to load charts.
          {selectedCos.length > 0 && ` (${selectedCos.length} companies selected)`}
        </Alert>
      )}

      {/* ═══════════════════════════════════════════════════════════
          SECTION 1 — Cost Structure Peer Comparison
          ═══════════════════════════════════════════════════════════ */}
      <Paper sx={{ p: 2, mb: 2.5 }}>
        <Stack direction="row" justifyContent="space-between" alignItems="center" mb={1.5} flexWrap="wrap" gap={1}>
          <Box>
            <Typography variant="subtitle1" fontWeight={700} color="#0B2545">
              Cost Structure Comparison
            </Typography>
            <Typography variant="caption" color="text.secondary">
              Sorted descending · Click segment to highlight · {period}
              {clickedSeg && ` · Highlighted: ${clickedSeg}`}
            </Typography>
          </Box>
          <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" gap={0.5}>
            {/* Display mode — 3 options */}
            <ToggleButtonGroup value={costMode} exclusive size="small"
              onChange={(_, v) => v && setCostMode(v)}
              sx={{ '& .MuiToggleButton-root': { px: 1.2, py: 0.4, fontSize: 10.5, textTransform: 'none' } }}>
              <ToggleButton value="absolute">Absolute (INR Mn)</ToggleButton>
              <ToggleButton value="pct_revenue">% Revenue</ToggleButton>
              <ToggleButton value="pct_total_cost">% Total Cost</ToggleButton>
            </ToggleButtonGroup>
            {/* Cost PNG export */}
            <Tooltip title={`Download PNG — cost_structure_comparison_${period}.png`}>
              <span>
                <Button size="small" variant="outlined" startIcon={<ImageIcon />}
                  onClick={exportCostPNG}
                  disabled={exporting !== null || cosWithData.length === 0}
                  sx={{ fontSize: 10.5, textTransform: 'none', minWidth: 0, px: 1.2 }}>
                  {exporting === 'cost-png' ? '…' : 'PNG'}
                </Button>
              </span>
            </Tooltip>
          </Stack>
        </Stack>

        {costLoading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', py: 5 }}><CircularProgress /></Box>
        ) : cosWithData.length > 0 ? (
          <Box sx={{ overflowX: cosWithData.length > 6 ? 'auto' : 'visible' }}
               id="cost-structure-chart">
            <Plot
              divId="cost-structure-plot"
              ref={costPlotRef}
              data={costTraces as any}
              layout={{
                barmode: 'stack',
                height: 440,
                width: Math.max(700, cosWithData.length * 130 + 200),
                margin: { t: 36, b: 70, l: 75, r: 20 },
                paper_bgcolor: 'transparent', plot_bgcolor: 'transparent',
                yaxis: {
                  title: yAxisTitle, gridcolor: '#E2E8F0',
                  tickformat: yTickFmt, zeroline: false,
                },
                xaxis: { tickfont: { size: 12, color: "#0B2545", family: "Inter, sans-serif" } },
                legend: { orientation: 'h', y: -0.22, font: { size: 10 }, traceorder: 'normal' },
                annotations: costAnnotations as any,
                hoverlabel: {
                  // Per-trace hoverlabel (defined on each trace) overrides this,
                  // but we keep a fallback for any traces that don't set it.
                  bgcolor: '#1E293B',
                  bordercolor: '#475569',
                  font: { size: 13, color: '#F8FAFC', family: 'Inter, sans-serif' },
                  align: 'left' as const,
                },
                font: { family: 'Inter, sans-serif', size: 12 },
              } as any}
              style={{ width: '100%' }}
              config={{ displayModeBar: false, responsive: true } as any}
              onClick={onCostClick}
            />
          </Box>
        ) : hasData ? (
          <Box sx={{ py: 4, textAlign: 'center' }}>
            <Typography color="text.secondary">
              No cost structure data available for selected companies/period.
            </Typography>
          </Box>
        ) : null}
      </Paper>

      {/* ═══════════════════════════════════════════════════════════
          SECTION 2 — Multi-Metric KPI Comparison
          ═══════════════════════════════════════════════════════════ */}
      <Paper sx={{ p: 2, mb: 2.5 }}>
        <Stack direction="row" justifyContent="space-between" alignItems="center" mb={1.5} flexWrap="wrap" gap={1}>
          <Box>
            <Typography variant="subtitle1" fontWeight={700} color="#0B2545">
              Multi-Metric KPI Comparison
            </Typography>
            <Typography variant="caption" color="text.secondary">
              Grouped by metric · One bar per company · {period}
            </Typography>
          </Box>
          <Stack direction="row" spacing={1}>
            <Tooltip title={`Download PNG — peer_kpi_comparison_${period}.png`}>
              <span>
                <Button size="small" variant="outlined" startIcon={<ImageIcon />}
                  onClick={exportMetricPNG}
                  disabled={exporting !== null || !metricData}
                  sx={{ fontSize: 11, textTransform: 'none' }}>
                  {exporting === 'metric-png' ? 'Generating…' : 'PNG'}
                </Button>
              </span>
            </Tooltip>
            <Tooltip title={`Download PPT — peer_kpi_comparison_${period}.pptx`}>
              <span>
                <Button size="small" variant="outlined" startIcon={<SlideshowIcon />}
                  onClick={exportMetricPPT}
                  disabled={exporting !== null || !metricData}
                  sx={{ fontSize: 11, textTransform: 'none' }}>
                  {exporting === 'metric-ppt' ? 'Generating…' : 'PPT'}
                </Button>
              </span>
            </Tooltip>
          </Stack>
        </Stack>

        {metricLoading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', py: 5 }}><CircularProgress /></Box>
        ) : metricTraces.length > 0 && metricData?.data?.some((d: any) => d.value != null) ? (
          <>
            <div id="multi-metric-chart">
              <Plot
                divId="multi-metric-plot"
              ref={metricPlotRef}
                data={metricTraces as any}
                layout={{
                  barmode: 'group',
                  height: 360,
                  margin: { t: 20, b: 100, l: 75, r: 20 },
                  paper_bgcolor: 'transparent', plot_bgcolor: 'transparent',
                  yaxis: { gridcolor: '#E2E8F0', tickformat: ',.0f', zeroline: false },
                  xaxis: { tickangle: 0, tickfont: { size: 11, color: "#0B2545", family: "Inter, sans-serif" }, automargin: true },
                  legend: { orientation: 'h', y: -0.32, font: { size: 11 } },
                  hoverlabel: {
                    bgcolor: '#1E293B', bordercolor: '#475569',
                    font: { size: 13, color: '#F8FAFC', family: 'Inter, sans-serif' },
                  },
                  font: { family: 'Inter, sans-serif', size: 12 },
                } as any}
                style={{ width: '100%' }}
                config={{ displayModeBar: false, responsive: true } as any}
              />
            </div>

            {/* Comparison table */}
            <Box sx={{ overflowX: 'auto', mt: 1 }}>
              <Table size="small">
                <TableHead>
                  <TableRow sx={{ '& th': { fontWeight: 700, bgcolor: '#F1F5F9', fontSize: 12 } }}>
                    <TableCell>Metric</TableCell>
                    {selectedCos.map((co, ci) => (
                      <TableCell align="right" key={co}
                        sx={{ color: COMPANY_COLORS[ci % COMPANY_COLORS.length], fontWeight: 700 }}>
                        {co}
                      </TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {selectedMetrics.map(m => {
                    const label = PEER_METRICS.find(x => x.value === m)?.label || m
                    const vals  = selectedCos.map(co => metricData?.table?.[m]?.[co])
                    const maxV  = Math.max(...vals.filter((v: any) => v != null).map(Number))
                    return (
                      <TableRow key={m} sx={{ '&:hover': { bgcolor: '#F8FAFC' } }}>
                        <TableCell><Typography fontSize={12} fontWeight={500}>{label}</Typography></TableCell>
                        {vals.map((v: any, ci: number) => {
                          const isBest = v != null && Number(v) === maxV && maxV > 0
                          return (
                            <TableCell align="right" key={selectedCos[ci]}>
                              <Typography fontSize={12} fontWeight={isBest ? 700 : 400}
                                color={isBest ? '#059669' : 'inherit'}>
                                {fmt(v)}{isBest ? ' ★' : ''}
                              </Typography>
                            </TableCell>
                          )
                        })}
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </Box>
          </>
        ) : metricData ? (
          <Box sx={{ py: 4, textAlign: 'center' }}>
            <Typography color="text.secondary">No KPI data for selected companies/period.</Typography>
          </Box>
        ) : (
          <Box sx={{ py: 4, textAlign: 'center' }}>
            <Typography color="text.secondary">Select companies and click <strong>Go</strong>.</Typography>
          </Box>
        )}
      </Paper>

      {/* ══════════════════════════════════════════════════════════
          SECTION 3 — Metric Trend Comparison
          ══════════════════════════════════════════════════════════ */}
      <Paper sx={{ p: 2, mb: 2.5 }}>
        <Stack direction="row" justifyContent="space-between" alignItems="center" mb={1.5} flexWrap="wrap" gap={1}>
          <Box>
            <Typography variant="subtitle1" fontWeight={700} color="#0B2545">
              Metric Trend Comparison
            </Typography>
            <Typography variant="caption" color="text.secondary">
              Single metric across companies over time
            </Typography>
          </Box>
          <ToggleButtonGroup value={trendViewMode} exclusive size="small"
            onChange={(_,v) => v && setTrendViewMode(v)}
            sx={{'& .MuiToggleButton-root':{ px:1.5, py:0.4, fontSize:11, textTransform:'none' }}}>
            <ToggleButton value="line">Line</ToggleButton>
            <ToggleButton value="bar">Bar</ToggleButton>
          </ToggleButtonGroup>
        </Stack>

        {/* Trend filters */}
        <Grid container spacing={1.5} mb={1.5} alignItems="flex-end">
          <Grid item xs={12} sm={4}>
            <FormControl fullWidth size="small">
              <InputLabel>Metric</InputLabel>
              <Select value={trendMetric} label="Metric" onChange={e => setTrendMetric(e.target.value)}>
                {TREND_METRICS.map(m => (
                  <MenuItem key={m.value} value={m.value}>{m.label}</MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={3}>
            <FormControl fullWidth size="small">
              <InputLabel>Start Year</InputLabel>
              <Select value={trendStartYear} label="Start Year" onChange={e => setTrendStartYear(e.target.value)}>
                {ALL_FY.map(y => <MenuItem key={y} value={y}>{y}</MenuItem>)}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={3}>
            <FormControl fullWidth size="small">
              <InputLabel>End Year</InputLabel>
              <Select value={trendEndYear} label="End Year" onChange={e => setTrendEndYear(e.target.value)}>
                {ALL_FY.map(y => <MenuItem key={y} value={y}>{y}</MenuItem>)}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={2}>
            <Button variant="contained" fullWidth onClick={fetchTrend}
              disabled={trendLoading || !selectedCos.length}
              startIcon={trendLoading ? <CircularProgress size={14} color="inherit"/> : <CompareArrowsIcon/>}
              sx={{ bgcolor:'#0D9488','&:hover':{bgcolor:'#0F766E'}, height:40 }}>
              {trendLoading ? 'Loading…' : 'Load'}
            </Button>
          </Grid>
        </Grid>

        {trendLoading ? (
          <Box sx={{display:'flex',justifyContent:'center',py:5}}><CircularProgress/></Box>
        ) : trendTraces.length > 0 && trendData?.series?.some((s:any) => s.values.some((v:any) => v!=null)) ? (
          <Plot
            data={trendTraces as any}
            layout={{
              height: 340,
              barmode: 'group',
              margin: { t: 20, b: 50, l: 70, r: 20 },
              paper_bgcolor: 'transparent', plot_bgcolor: 'transparent',
              xaxis: {
                tickfont: { size: 12, color: '#0B2545', family: 'Inter, sans-serif' },
                tickangle: 0,
                gridcolor: '#E2E8F0',
                showgrid: false,
              },
              yaxis: {
                title: { text: trendLabel, font: { size: 12 } },
                gridcolor: '#E2E8F0',
                tickformat: ',.0f',
                zeroline: false,
              },
              legend: { orientation:'h', y:-0.18, font:{ size:11 } },
              hoverlabel: { bgcolor:'#1E293B', bordercolor:'#475569', font:{ size:12, color:'#F8FAFC' } },
              font: { family:'Inter, sans-serif', size:12 },
            } as any}
            style={{ width:'100%' }}
            config={{ displayModeBar: false, responsive: true } as any}
          />
        ) : trendData ? (
          <Box sx={{py:4, textAlign:'center'}}>
            <Typography color="text.secondary">No data for selected metric and year range.</Typography>
          </Box>
        ) : (
          <Box sx={{py:4, textAlign:'center'}}>
            <Typography color="text.secondary">
              Select metric and year range above, then click <strong>Load</strong>.
            </Typography>
          </Box>
        )}
      </Paper>

      {/* ── Sector Ranking ── */}
      {ranking.length > 0 && (
        <Paper sx={{ p: 2 }}>
          <Typography variant="subtitle1" fontWeight={700} mb={1.5} color="#0B2545">
            Sector Ranking — {period}
          </Typography>
          <Box sx={{ overflowX: 'auto' }}>
            <Table size="small">
              <TableHead>
                <TableRow sx={{ '& th': { fontWeight: 700, bgcolor: '#F1F5F9', fontSize: 12 } }}>
                  <TableCell>#</TableCell><TableCell>Company</TableCell>
                  <TableCell align="right">Revenue</TableCell>
                  <TableCell align="right">EBITDA</TableCell>
                  <TableCell align="right">PAT</TableCell>
                  <TableCell align="right">Z Score</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {ranking.map((row: any, i: number) => (
                  <TableRow key={row.company_id}
                    sx={{ bgcolor: selectedCos.includes(row.company_id) ? '#EFF6FF' : 'transparent', '&:hover': { bgcolor: '#F8FAFC' } }}>
                    <TableCell>
                      <Chip label={i + 1} size="small"
                        sx={{ bgcolor: i === 0 ? '#FEF9C3' : i === 1 ? '#F1F5F9' : 'transparent', fontWeight: 700, minWidth: 26, height: 22 }} />
                    </TableCell>
                    <TableCell><Typography fontSize={13} fontWeight={600}>{row.company_id}</Typography></TableCell>
                    <TableCell align="right"><Typography fontSize={12}>{fmt(row.revenue)}</Typography></TableCell>
                    <TableCell align="right"><Typography fontSize={12}>{fmt(row.ebitda)}</Typography></TableCell>
                    <TableCell align="right"><Typography fontSize={12}>{fmt(row.pat)}</Typography></TableCell>
                    <TableCell align="right">
                      {row.altman_z != null
                        ? <Chip label={Number(row.altman_z).toFixed(2)} size="small"
                            sx={{ bgcolor: row.altman_z > 2.99 ? '#ECFDF5' : row.altman_z > 1.81 ? '#FFFBEB' : '#FEF2F2',
                              color: row.altman_z > 2.99 ? '#059669' : row.altman_z > 1.81 ? '#D97706' : '#DC2626',
                              fontWeight: 700, fontSize: 11 }} />
                        : <Typography fontSize={12} color="text.secondary">—</Typography>}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Box>
        </Paper>
      )}

      {/* Toast */}
      <Snackbar open={!!toast} autoHideDuration={3500} onClose={() => setToast('')}
        message={toast} anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }} />
    </Box>
  )
}
