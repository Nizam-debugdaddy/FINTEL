import React, { useState, useEffect, createContext, useContext } from 'react'
import { createTheme, ThemeProvider, CssBaseline } from '@mui/material'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import AppShell from './components/layout/AppShell'
import InputPage from './components/input/InputPage'
import DashboardPage from './components/dashboard/DashboardPage'
import PeerPage from './components/dashboard/PeerPage'
import AdvancedAnalyticsPage from './components/dashboard/AdvancedAnalyticsPage'
import ExportPage from './components/export/ExportPage'
import { fetchCompanies, Company } from './api/client'

export interface GlobalFilter {
  company: string
  periodType: 'annual' | 'quarterly'
  period: string
  reportType: 'consolidated' | 'standalone'
}

export const FilterContext = createContext<{
  filter: GlobalFilter
  setFilter: (f: Partial<GlobalFilter>) => void
  companies: Company[]
  refreshCompanies: () => void
}>({
  filter: { company: '', periodType: 'annual', period: 'FY25', reportType: 'consolidated' },
  setFilter: () => {},
  companies: [],
  refreshCompanies: () => {},
})

export const useFilter = () => useContext(FilterContext)

const theme = createTheme({
  palette: {
    primary:    { main: '#0B2545' },
    secondary:  { main: '#0D9488' },
    background: { default: '#F1F5F9', paper: '#FFFFFF' },
  },
  typography: { fontFamily: "'Inter', -apple-system, sans-serif" },
  components: {
    MuiButton:       { styleOverrides: { root: { textTransform: 'none', fontWeight: 500, borderRadius: 6 } } },
    MuiCard:         { styleOverrides: { root: { borderRadius: 12, boxShadow: '0 1px 3px rgba(0,0,0,0.08)' } } },
    MuiOutlinedInput:{ styleOverrides: { root: { borderRadius: 8 } } },
  },
})

// Derive period list from type
export function getPeriods(type: 'annual' | 'quarterly'): string[] {
  const out: string[] = []
  if (type === 'annual') {
    for (let y = 30; y >= 19; y--) out.push(`FY${String(y).padStart(2,'0')}`)
    return out
  }
  for (let y = 30; y >= 19; y--) {
    for (let q = 1; q <= 4; q++) out.push(`Q${q}FY${String(y).padStart(2,'0')}`)
  }
  return out
}

export default function App() {
  const [companies, setCompanies] = useState<Company[]>([])
  const [filter, setFilterState] = useState<GlobalFilter>({
    company: '', periodType: 'annual', period: 'FY25', reportType: 'consolidated',
  })
  const [tick, setTick] = useState(0)

  useEffect(() => {
    fetchCompanies()
      .then(data => {
        setCompanies(data)
        if (data.length > 0 && !filter.company)
          setFilterState(f => ({ ...f, company: data[0].company_id }))
      })
      .catch(console.error)
  }, [tick])

  const setFilter = (partial: Partial<GlobalFilter>) =>
    setFilterState(f => ({ ...f, ...partial }))

  return (
    <FilterContext.Provider value={{ filter, setFilter, companies, refreshCompanies: () => setTick(t => t+1) }}>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <BrowserRouter>
          <AppShell>
            <Routes>
              <Route path="/" element={<Navigate to="/input" replace />} />
              <Route path="/input"     element={<InputPage />} />
              <Route path="/dashboard" element={<DashboardPage />} />
              <Route path="/peer"      element={<PeerPage />} />
              <Route path="/advanced"  element={<AdvancedAnalyticsPage />} />
              <Route path="/export"    element={<ExportPage />} />
            </Routes>
          </AppShell>
        </BrowserRouter>
      </ThemeProvider>
    </FilterContext.Provider>
  )
}
